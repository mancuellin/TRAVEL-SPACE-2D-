using UnityEngine;

public enum PartType
{
    Structure,
    SolarPanel,
    RTG,
    Battery,
    Antenna,
    Computer,
    Instrument,
    Fuel,
    Shielding
}

// Esto agrega una opción al menú de Unity: Create > Orbital Trade-Off > Part
[CreateAssetMenu(fileName = "NewPart", menuName = "Orbital Trade-Off/Part")]
public class PartData : ScriptableObject
{
    [Header("General")]
    public string partName = "Nueva pieza";
    public PartType type;
    [Tooltip("Masa de la pieza en kg (sin contar el combustible)")]
    public float massKg;
    [Tooltip("Costo en millones de dólares")]
    public float costMillions;

    [Header("Energía")]
    [Tooltip("Positivo = genera energía (panel, RTG). Negativo = consume.")]
    public float powerWatts;
    [Tooltip("Capacidad de batería en Wh (watts-hora)")]
    public float batteryWh;

    [Header("Otros")]
    [Tooltip("Kg de combustible que lleva esta pieza (solo tanques)")]
    public float fuelKg;
    [Tooltip("Puntos de ciencia que aporta (solo instrumentos)")]
    public float sciencePoints;

    [Header("Solo antenas")]
    [Range(0f, 1f)]
    [Tooltip("Fracción de la ciencia que logra transmitir a la Tierra (omni = 0.5, parábola = 1)")]
    public float dataRate = 0.5f;

    [Header("Solo computadoras")]
    [Tooltip("Cuántas tormentas de radiación severas aguanta (simple = 1, redundante = 2)")]
    public int computerLives = 1;

    [Header("Solo blindaje")]
    [Range(0f, 0.8f)]
    [Tooltip("Cuánto reduce la intensidad de las tormentas (se suma entre piezas, máximo 0.8)")]
    public float shielding = 0f;
}
