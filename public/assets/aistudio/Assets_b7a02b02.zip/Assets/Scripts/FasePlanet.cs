using UnityEngine;

public class FasePlanet : MonoBehaviour
{
    public enum Fase { Dia, Atardecer, Noche }

    [Header("Sprites")]
    [SerializeField] private Sprite dia;
    [SerializeField] private Sprite atardecer;
    [SerializeField] private Sprite noche;

    [Header("Ciclo automático")]
    [SerializeField] private bool cicloAutomatico = true;
    [SerializeField] private float segundosPorFase = 5f;

    [Header("Fase actual")]
    [SerializeField] private Fase faseActual = Fase.Dia;

    [Header("Transición")]
    [SerializeField] private bool transicionSuave = true;
    [SerializeField] private float duracionTransicion = 1.8f;

    private SpriteRenderer sr;
    private SpriteRenderer srOverlay;
    private Coroutine corutinaFade;
    private float temporizador;

#if UNITY_EDITOR
    void Reset() => AutoAssign();
    void OnValidate() => AutoAssign();

    void AutoAssign()
    {
        if (dia == null)
            dia = LoadFirstSprite("Assets/Arte/earth_day.png");
        if (atardecer == null)
            atardecer = LoadFirstSprite("Assets/Arte/earth_sunset.png");
        if (noche == null)
            noche = LoadFirstSprite("Assets/Arte/earth_night.png");
    }

    private static Sprite LoadFirstSprite(string path)
    {
        var assets = UnityEditor.AssetDatabase.LoadAllAssetsAtPath(path);
        if (assets != null)
        {
            foreach (var a in assets)
            {
                if (a is Sprite s) return s;
            }
        }
        return null;
    }
#endif

    void Awake()
    {
#if UNITY_EDITOR
        if (dia == null || atardecer == null || noche == null) AutoAssign();
#endif
        sr = GetComponent<SpriteRenderer>();
        AplicarFase(faseActual);
    }

    void Update()
    {
        if (!cicloAutomatico) return;

        temporizador += Time.deltaTime;
        if (temporizador >= segundosPorFase)
        {
            temporizador = 0f;
            // Orden: Día -> Atardecer -> Noche -> Atardecer (amanecer) -> Día...
            Siguiente();
        }
    }

    private int paso = 0;
    private readonly Fase[] secuencia =
        { Fase.Dia, Fase.Atardecer, Fase.Noche, Fase.Atardecer };

    private void Siguiente()
    {
        paso = (paso + 1) % secuencia.Length;
        AplicarFase(secuencia[paso]);
    }

    private Sprite ObtenerSprite(Fase fase)
    {
        switch (fase)
        {
            case Fase.Dia:       return dia;
            case Fase.Atardecer: return atardecer;
            case Fase.Noche:     return noche;
            default:             return dia;
        }
    }

    public void AplicarFase(Fase fase)
    {
        faseActual = fase;
        if (sr == null) sr = GetComponent<SpriteRenderer>();
        if (sr == null) return;

        Sprite nuevoSprite = ObtenerSprite(fase);

        if (!transicionSuave || !Application.isPlaying || sr.sprite == null)
        {
            sr.sprite = nuevoSprite;
            return;
        }

        if (sr.sprite != nuevoSprite)
        {
            if (corutinaFade != null) StopCoroutine(corutinaFade);
            corutinaFade = StartCoroutine(HacerTransicion(nuevoSprite));
        }
    }

    private System.Collections.IEnumerator HacerTransicion(Sprite nuevoSprite)
    {
        if (srOverlay == null)
        {
            Transform tOverlay = transform.Find("FadeOverlay");
            if (tOverlay == null)
            {
                var go = new GameObject("FadeOverlay");
                go.transform.SetParent(transform, false);
                srOverlay = go.AddComponent<SpriteRenderer>();
            }
            else
            {
                srOverlay = tOverlay.GetComponent<SpriteRenderer>();
            }
        }

        srOverlay.sprite = nuevoSprite;
        srOverlay.sortingLayerID = sr.sortingLayerID;
        srOverlay.sortingOrder = sr.sortingOrder + 1;
        srOverlay.color = new Color(1f, 1f, 1f, 0f);

        float elapsed = 0f;
        while (elapsed < duracionTransicion)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / duracionTransicion);
            srOverlay.color = new Color(1f, 1f, 1f, t);
            yield return null;
        }

        sr.sprite = nuevoSprite;
        srOverlay.color = new Color(1f, 1f, 1f, 0f);
        corutinaFade = null;
    }

    // Para llamarlo desde otros scripts: planeta.FijarFase(FasePlanet.Fase.Noche);
    public void FijarFase(Fase fase)
    {
        cicloAutomatico = false;
        AplicarFase(fase);
    }
}

// Alias para compatibilidad
public class FasePlaneta : FasePlanet {}
