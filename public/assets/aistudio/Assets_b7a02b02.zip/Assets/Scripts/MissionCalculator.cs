using System.Collections.Generic;
using System.Text;
using UnityEngine;

// Resultado del cálculo: aquí se guardan todos los números y errores.
public class MissionResult
{
    public float dryMassKg;
    public float fuelMassKg;
    public float totalMassKg;
    public float launcherCapacityKg;

    public float partsCost;
    public float totalCost;
    public float budget;

    public float solarWatts;
    public float rtgWatts;
    public float consumptionWatts;
    public float batteryWh;

    public float periodMinutes;
    public float eclipseMinutes;
    public float energyNeededInEclipseWh;

    public float deltaVAvailable;
    public float deltaVRequired;

    public float sciencePoints;
    public float minScience;

    public List<string> errors = new List<string>();
    public bool IsValid { get { return errors.Count == 0; } }

    public string ToReport()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== MASA ===");
        sb.AppendLine("Masa total: " + totalMassKg.ToString("F0") + " kg / " + launcherCapacityKg.ToString("F0") + " kg (lanzador)");
        sb.AppendLine("  Seca: " + dryMassKg.ToString("F0") + " kg   Combustible: " + fuelMassKg.ToString("F0") + " kg");
        sb.AppendLine();
        sb.AppendLine("=== COSTO ===");
        sb.AppendLine("Costo total: $" + totalCost.ToString("F1") + "M / $" + budget.ToString("F1") + "M");
        sb.AppendLine();
        sb.AppendLine("=== ENERGÍA ===");
        sb.AppendLine("Paneles: " + solarWatts.ToString("F0") + " W   RTG: " + rtgWatts.ToString("F0") + " W   Consumo: " + consumptionWatts.ToString("F0") + " W");
        sb.AppendLine("Batería: " + batteryWh.ToString("F0") + " Wh (necesita " + energyNeededInEclipseWh.ToString("F0") + " Wh en eclipse)");
        sb.AppendLine("Periodo orbital: " + periodMinutes.ToString("F0") + " min   Eclipse: " + eclipseMinutes.ToString("F0") + " min");
        sb.AppendLine();
        sb.AppendLine("=== ΔV ===");
        sb.AppendLine("Disponible: " + deltaVAvailable.ToString("F0") + " m/s / Requerido: " + deltaVRequired.ToString("F0") + " m/s");
        sb.AppendLine();
        sb.AppendLine("=== CIENCIA ===");
        sb.AppendLine("Puntos: " + sciencePoints.ToString("F0") + " / mínimo " + minScience.ToString("F0"));
        sb.AppendLine();
        if (IsValid)
        {
            sb.AppendLine("RESULTADO: MISIÓN APROBADA");
        }
        else
        {
            sb.AppendLine("RESULTADO: MISIÓN RECHAZADA");
            foreach (var e in errors) sb.AppendLine(" - " + e);
        }
        return sb.ToString();
    }
}

// La calculadora: no usa MonoBehaviour, solo recibe datos y devuelve un resultado.
public static class MissionCalculator
{
    const float EarthRadiusKm = 6371f;
    const float EarthMu = 398600.4418f;   // km^3 / s^2
    const float G0 = 9.80665f;            // m/s^2
    public const float IspSeconds = 300f; // eficiencia del motor (constante por ahora)

    public static MissionResult Calculate(List<PartData> parts, LauncherData launcher, OrbitData orbit, MissionBriefing briefing)
    {
        var r = new MissionResult();

        // 1) Sumar todas las piezas
        foreach (var p in parts)
        {
            if (p == null) continue;
            r.dryMassKg += p.massKg;
            r.fuelMassKg += p.fuelKg;
            r.partsCost += p.costMillions;
            r.batteryWh += p.batteryWh;
            r.sciencePoints += p.sciencePoints;

            if (p.powerWatts > 0)
            {
                if (p.type == PartType.RTG) r.rtgWatts += p.powerWatts;
                else r.solarWatts += p.powerWatts;
            }
            else
            {
                r.consumptionWatts += -p.powerWatts;
            }
        }

        r.totalMassKg = r.dryMassKg + r.fuelMassKg;
        r.totalCost = r.partsCost;

        // 2) Lanzador
        if (launcher == null)
        {
            r.errors.Add("No hay lanzador seleccionado.");
        }
        else
        {
            r.totalCost += launcher.costMillions;
            r.launcherCapacityKg = launcher.capacityKg;
            if (r.totalMassKg > launcher.capacityKg)
                r.errors.Add("La masa (" + r.totalMassKg.ToString("F0") + " kg) supera la capacidad del lanzador (" + launcher.capacityKg.ToString("F0") + " kg).");
        }

        // 3) Presupuesto y ciencia
        if (briefing != null)
        {
            r.budget = briefing.budgetMillions;
            r.minScience = briefing.minSciencePoints;
            if (r.totalCost > briefing.budgetMillions)
                r.errors.Add("Presupuesto excedido: $" + r.totalCost.ToString("F1") + "M de $" + briefing.budgetMillions.ToString("F1") + "M.");
            if (r.sciencePoints < briefing.minSciencePoints)
                r.errors.Add("Ciencia insuficiente: " + r.sciencePoints.ToString("F0") + " de " + briefing.minSciencePoints.ToString("F0") + " puntos.");
        }

        // 4) ΔV (ecuación de Tsiolkovsky)
        if (r.dryMassKg > 0f && r.fuelMassKg > 0f)
            r.deltaVAvailable = IspSeconds * G0 * Mathf.Log(r.totalMassKg / r.dryMassKg);

        if (orbit == null)
        {
            r.errors.Add("No hay órbita seleccionada.");
            return r;
        }

        r.deltaVRequired = orbit.deltaVRequired;
        if (r.deltaVAvailable < orbit.deltaVRequired)
            r.errors.Add("ΔV insuficiente: " + r.deltaVAvailable.ToString("F0") + " m/s de " + orbit.deltaVRequired.ToString("F0") + " m/s. Falta combustible.");

        // 5) Órbita: periodo y eclipse
        float rKm = EarthRadiusKm + orbit.altitudeKm;
        float periodSec = 2f * Mathf.PI * Mathf.Sqrt((rKm * rKm * rKm) / EarthMu);
        float eclipseFraction = Mathf.Asin(EarthRadiusKm / rKm) / Mathf.PI;

        r.periodMinutes = periodSec / 60f;
        r.eclipseMinutes = r.periodMinutes * eclipseFraction;
        float eclipseHours = r.eclipseMinutes / 60f;
        float daylightHours = (r.periodMinutes - r.eclipseMinutes) / 60f;

        // 6) Balance de energía
        float daylightPower = r.solarWatts + r.rtgWatts;
        if (daylightPower < r.consumptionWatts)
        {
            r.errors.Add("Energía insuficiente a plena luz: genera " + daylightPower.ToString("F0") + " W y consume " + r.consumptionWatts.ToString("F0") + " W.");
        }

        float eclipseDeficitW = r.consumptionWatts - r.rtgWatts; // en sombra solo funciona el RTG
        r.energyNeededInEclipseWh = Mathf.Max(0f, eclipseDeficitW) * eclipseHours;

        if (r.energyNeededInEclipseWh > r.batteryWh)
        {
            r.errors.Add("Faltó batería para cubrir la fase de sombra de " + r.eclipseMinutes.ToString("F0") + " min.");
        }
        else if (daylightPower >= r.consumptionWatts)
        {
            float rechargeWh = (daylightPower - r.consumptionWatts) * daylightHours;
            if (rechargeWh < r.energyNeededInEclipseWh)
                r.errors.Add("Los paneles no alcanzan a recargar la batería durante la luz del día.");
        }

        return r;
    }
}
