using System.Collections.Generic;
using UnityEngine;

public enum LogKind { Info, Good, Bad }

public class OperationEvent
{
    public int day;
    public string text;
    public LogKind kind;
}

public enum OperationOutcome { Running, Success, FailedPower, FailedComputer, FailedScience }

// Simulación de la vida útil de la nave, día por día. Es C# puro (sin MonoBehaviour).
// Eventos al azar: degradación solar, tormentas de radiación y fallos de antena.
public class MissionOperation
{
    const float StormThreshold = 0.5f;          // intensidad (tras el blindaje) que daña la computadora
    const float AntennaFailProbPerDay = 0.004f;
    const int AntennaOutageDays = 10;

    // ---------- Configuración (se calcula con tu diseño) ----------
    public int TotalDays { get; private set; }
    public float RadiationLevel { get; private set; }
    public float ShieldingFactor { get; private set; }
    public int ComputerLivesTotal { get; private set; }
    public int AntennaCount { get; private set; }
    public float DataRate { get; private set; }
    public float SciencePoints { get; private set; }
    public float MinScience { get; private set; }
    public float StormProbPerDay { get; private set; }
    public float SolarLossPerDay { get; private set; }

    // ---------- Estado ----------
    public int Day { get; private set; }
    public float SolarHealth { get; private set; }
    public int ComputerLivesLeft { get; private set; }
    public float ScienceDelivered { get; private set; }
    public int OutageDaysTotal { get; private set; }
    public OperationOutcome Outcome { get; private set; }
    public string FailureCause { get; private set; }
    public string Advice { get; private set; }
    public float Score { get; private set; }

    public readonly List<OperationEvent> Log = new List<OperationEvent>();
    public readonly List<string> ScoreLines = new List<string>();

    public bool Finished { get { return Outcome != OperationOutcome.Running; } }
    public bool Succeeded { get { return Outcome == OperationOutcome.Success; } }
    public bool ComputerAlive { get { return ComputerLivesLeft > 0; } }
    public bool LinkUp { get { return linkDownDaysLeft <= 0; } }
    public int LinkDownDaysLeft { get { return Mathf.Max(0, linkDownDaysLeft); } }

    readonly MissionResult res;
    readonly System.Random rng;
    int linkDownDaysLeft;
    float dailyScience;
    float nextHealthMilestone = 0.9f;

    public MissionOperation(List<PartData> parts, MissionResult result, OrbitData orbit, MissionBriefing briefing, int seed)
    {
        res = result;
        rng = new System.Random(seed);
        Outcome = OperationOutcome.Running;

        float shield = 0f;
        foreach (var p in parts)
        {
            if (p == null) continue;
            if (p.type == PartType.Computer) ComputerLivesTotal += Mathf.Max(1, p.computerLives);
            else if (p.type == PartType.Antenna)
            {
                AntennaCount++;
                DataRate = Mathf.Max(DataRate, p.dataRate > 0f ? p.dataRate : 0.5f);
            }
            else if (p.type == PartType.Shielding) shield += p.shielding;
        }
        ShieldingFactor = Mathf.Min(0.8f, shield);

        SciencePoints = result.sciencePoints;
        MinScience = (briefing != null) ? briefing.minSciencePoints : 0f;
        TotalDays = (briefing != null && briefing.missionDays > 0f) ? Mathf.RoundToInt(briefing.missionDays) : 180;

        // LEO está protegida por el campo magnético; MEO cruza los cinturones de radiación; GEO queda en medio.
        float alt = (orbit != null) ? orbit.altitudeKm : 400f;
        RadiationLevel = (alt < 1500f) ? 0.2f : ((alt < 30000f) ? 1f : 0.6f);
        StormProbPerDay = 0.01f * RadiationLevel;
        SolarLossPerDay = 0.002f * RadiationLevel;

        dailyScience = SciencePoints / TotalDays * DataRate;
        SolarHealth = 1f;
        ComputerLivesLeft = ComputerLivesTotal;

        string orbitName = (orbit != null) ? orbit.orbitName : "?";
        Add(0, "Operación iniciada en órbita " + orbitName + ": " + TotalDays + " días de vida útil.", LogKind.Info);

        if (AntennaCount == 0)
            Add(0, "Atención: la nave no lleva antena, no podrá enviar ciencia.", LogKind.Bad);

        if (ComputerLivesTotal <= 0)
        {
            Fail("La nave no lleva computadora: no puede ejecutar ningún comando.",
                 "Agrega una computadora (simple o redundante) en el Blueprint.", OperationOutcome.FailedComputer);
        }
    }

    // Avanza un día de misión.
    public void StepDay()
    {
        if (Finished) return;
        Day++;

        // 1) Degradación de los paneles
        SolarHealth *= (1f - SolarLossPerDay);
        if (SolarHealth < nextHealthMilestone)
        {
            Add(Day, "Los paneles solares bajaron al " + F(SolarHealth * 100f) + "% de su capacidad.", LogKind.Info);
            nextHealthMilestone -= 0.1f;
        }

        // 2) Balance de energía con los paneles ya degradados
        string why;
        if (!PowerOk(SolarHealth, out why))
        {
            string advice = (Day <= 1)
                ? "Tu diseño no cerraba el balance de energía desde el primer día: agrega paneles o baterías, o quita consumos."
                : "La degradación solar (paneles al " + F(SolarHealth * 100f) + "%) se comió tu margen de energía. Diseña con paneles de sobra para toda la vida útil.";
            Fail("Día " + Day + ": " + why, advice, OperationOutcome.FailedPower);
            return;
        }

        // 3) Tormenta de radiación
        if (NextF() < StormProbPerDay)
        {
            float sev = 0.3f + 0.7f * NextF();
            float eff = sev * (1f - ShieldingFactor);
            string txt = "Tormenta de radiación: intensidad " + F(sev * 100f) + "%" +
                         (ShieldingFactor > 0f ? " (" + F(eff * 100f) + "% tras el blindaje)" : "") + ".";

            if (eff > StormThreshold)
            {
                ComputerLivesLeft--;
                if (ComputerLivesLeft > 0)
                {
                    Add(Day, txt + " La computadora falló y conmutó al respaldo. Quedan " + ComputerLivesLeft + " vida(s).", LogKind.Bad);
                }
                else
                {
                    Add(Day, txt, LogKind.Bad);
                    Fail("Día " + Day + ": " + txt + " La computadora no tenía más respaldo y quedó fuera de servicio.",
                         "Usa la computadora redundante o agrega blindaje. El riesgo de perderla con este diseño era del " + F(ComputerLossRisk() * 100f) + "%.",
                         OperationOutcome.FailedComputer);
                    return;
                }
            }
            else
            {
                Add(Day, txt + " El sistema la resistió.", LogKind.Good);
            }
        }

        // 4) Fallo de antena
        if (AntennaCount > 0 && NextF() < AntennaFailProbPerDay)
        {
            if (AntennaCount >= 2)
            {
                Add(Day, "Falló una antena, pero la de respaldo mantuvo el enlace.", LogKind.Good);
            }
            else
            {
                linkDownDaysLeft = AntennaOutageDays;
                OutageDaysTotal += AntennaOutageDays;
                Add(Day, "Fallo de antena: el enlace queda caído " + AntennaOutageDays + " días.", LogKind.Bad);
            }
        }

        // 5) Transmisión de ciencia
        if (linkDownDaysLeft > 0)
        {
            linkDownDaysLeft--;
            if (linkDownDaysLeft == 0) Add(Day, "Enlace de datos restablecido.", LogKind.Good);
        }
        else
        {
            ScienceDelivered += dailyScience;
        }

        if (Day >= TotalDays) Complete();
    }

    // ---------- Análisis ----------

    // Misma lógica del MissionCalculator, pero con los paneles degradados.
    bool PowerOk(float health, out string why)
    {
        why = "";
        float solar = res.solarWatts * health;
        float daylight = solar + res.rtgWatts;
        float cons = res.consumptionWatts;

        if (daylight < cons)
        {
            why = "a plena luz los paneles (al " + F(health * 100f) + "% de su capacidad) generan " + F(daylight) +
                  " W y la nave consume " + F(cons) + " W.";
            return false;
        }

        float eclipseH = res.eclipseMinutes / 60f;
        float dayH = (res.periodMinutes - res.eclipseMinutes) / 60f;
        float need = Mathf.Max(0f, cons - res.rtgWatts) * eclipseH;

        if (need > res.batteryWh)
        {
            why = "faltó batería para cubrir la fase de sombra de " + F(res.eclipseMinutes) + " min (" +
                  F(need) + " Wh necesarios, " + F(res.batteryWh) + " Wh disponibles).";
            return false;
        }

        float recharge = (daylight - cons) * dayH;
        if (need > 0f && recharge < need)
        {
            why = "los paneles no alcanzan a recargar la batería en los " + F(dayH * 60f) + " min de luz de cada órbita.";
            return false;
        }
        return true;
    }

    void Complete()
    {
        if (ScienceDelivered >= MinScience)
        {
            Outcome = OperationOutcome.Success;
            Add(Day, "Fin de la misión: objetivos científicos cumplidos.", LogKind.Good);
            ComputeScore();
            return;
        }

        string cause = "Se entregaron " + F(ScienceDelivered) + " puntos de ciencia de los " + F(MinScience) + " requeridos.";
        string advice = "";
        if (AntennaCount == 0)
            advice = "La nave no llevaba antena: sin ella no hay datos que enviar. ";
        else if (DataRate < 1f)
            advice = "Tu antena solo transmite el " + F(DataRate * 100f) + "% de los datos. Una parábola dirigible transmite más, pero consume más energía. ";
        if (OutageDaysTotal > 0)
            advice += "Además el enlace estuvo caído " + OutageDaysTotal + " días: una segunda antena habría evitado esa pérdida. ";
        if (SciencePoints < MinScience)
            advice += "Y tus instrumentos solo generan " + F(SciencePoints) + " puntos en total.";

        Outcome = OperationOutcome.FailedScience;
        FailureCause = cause;
        Advice = advice.Trim();
        Add(Day, "Fin de la misión: ciencia insuficiente.", LogKind.Bad);
    }

    void Fail(string cause, string advice, OperationOutcome kind)
    {
        Outcome = kind;
        FailureCause = cause;
        Advice = advice;
        Score = 0f;
        Add(Day, "MISIÓN PERDIDA.", LogKind.Bad);
    }

    // Matriz de eficiencia: premia cumplir la misión con márgenes pequeños (diseño optimizado).
    void ComputeScore()
    {
        ScoreLines.Clear();
        float pts = 40f;
        ScoreLines.Add("Misión completada: +40");

        float sci = 20f * Mathf.Clamp01(ScienceDelivered / Mathf.Max(1f, 1.5f * MinScience));
        ScoreLines.Add("Ciencia entregada (" + F(ScienceDelivered) + " puntos): +" + sci.ToString("F1") + " de 20");
        pts += sci;

        ScoreLines.Add("Márgenes sobrantes (menos margen = mejor optimizado):");

        float massM = (res.launcherCapacityKg > 0f) ? (res.launcherCapacityKg - res.totalMassKg) / res.launcherCapacityKg : 1f;
        float dvM = (res.deltaVAvailable - res.deltaVRequired) / Mathf.Max(1f, res.deltaVRequired);
        float costM = (res.budget > 0f) ? (res.budget - res.totalCost) / res.budget : 1f;
        float batM = (res.batteryWh > 0f) ? (res.batteryWh - res.energyNeededInEclipseWh) / res.batteryWh : 1f;

        pts += Margin("  Masa del lanzador", massM);
        pts += Margin("  ΔV", dvM);
        pts += Margin("  Presupuesto", costM);
        pts += Margin("  Batería", batM);

        Score = pts;
    }

    float Margin(string name, float m)
    {
        float p = 10f * (1f - Mathf.Clamp01(m));
        ScoreLines.Add(name + ": sobra " + F(Mathf.Max(0f, m) * 100f) + "% → +" + p.ToString("F1") + " de 10");
        return p;
    }

    public string Rating
    {
        get
        {
            if (Score >= 85f) return "Ingeniería excelente";
            if (Score >= 70f) return "Buen diseño";
            if (Score >= 55f) return "Aprobado, pero sobredimensionado";
            return "Funcional, pero poco eficiente";
        }
    }

    // ---------- Riesgos esperados (matemática, no azar) ----------

    // Fracción de tormentas lo bastante fuertes para dañar la computadora (intensidad ~ uniforme entre 30 % y 100 %).
    float SevereFraction()
    {
        float thrSev = StormThreshold / (1f - ShieldingFactor);
        return Mathf.Clamp01((1f - thrSev) / 0.7f);
    }

    public float ExpectedSevereStorms { get { return TotalDays * StormProbPerDay * SevereFraction(); } }

    public float ExpectedSolarHealthAtEnd()
    {
        return Mathf.Pow(1f - SolarLossPerDay, TotalDays);
    }

    // Probabilidad de que lleguen más tormentas severas que "vidas" tiene la computadora (distribución de Poisson).
    public float ComputerLossRisk()
    {
        if (ComputerLivesTotal <= 0) return 1f;
        float lambda = ExpectedSevereStorms;
        float term = Mathf.Exp(-lambda);
        float cum = 0f;
        for (int k = 0; k < ComputerLivesTotal; k++)
        {
            cum += term;
            term *= lambda / (k + 1);
        }
        return Mathf.Clamp01(1f - cum);
    }

    // ---------- Utilidades ----------

    float NextF() { return (float)rng.NextDouble(); }

    void Add(int day, string text, LogKind kind)
    {
        Log.Add(new OperationEvent { day = day, text = text, kind = kind });
    }

    static string F(float v) { return v.ToString("F0"); }
}
