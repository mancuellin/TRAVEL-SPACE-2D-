using System.Collections.Generic;
using UnityEngine;

// HISTORIA DE INICIO
// John (21 años) recibe una carta de la NASA, se despide de sus padres,
// viaja en auto al centro espacial y recibe las instrucciones de su misión.
//
// - Todas las imágenes son OPCIONALES: si dejas un espacio vacío, se dibuja un reemplazo
//   para que puedas probar la historia igual.
// - Los TEXTOS de la historia están en el método BuildStory(), más abajo. Edítalos libremente.
public class StoryIntro : MonoBehaviour
{
    // ============================================================
    //  IMÁGENES (arrástralas desde la carpeta del proyecto)
    // ============================================================
    [Header("PERSONAJES (PNG con fondo transparente)")]
    public Texture2D john;
    public Texture2D mom;
    public Texture2D dad;
    [Tooltip("La persona de la NASA que te recibe y te explica la misión")]
    public Texture2D officer;

    [Header("FONDOS (ideal 1920x1080)")]
    public Texture2D homeBackground;
    public Texture2D roadBackground;
    public Texture2D nasaBackground;

    [Header("AUTO Y CARTA")]
    public Texture2D car;
    [Tooltip("Imagen del sobre o carta (opcional)")]
    public Texture2D letter;

    // ============================================================
    //  AJUSTES
    // ============================================================
    [Header("AJUSTES DEL AUTO")]
    [Tooltip("Marca esto si en tu imagen el auto mira hacia la DERECHA. Si mira a la izquierda, desmárcalo.")]
    public bool carFacesRight = true;
    [Tooltip("Qué tan abajo van las ruedas (0.5 = mitad de la pantalla, 0.95 = casi abajo)")]
    [Range(0.5f, 0.95f)] public float carBottom = 0.80f;
    [Tooltip("Cuántos segundos dura el viaje en auto")]
    public float driveSeconds = 8f;

    [Header("AJUSTES DE PERSONAJES")]
    [Tooltip("Altura de los personajes como fracción de la pantalla")]
    [Range(0.3f, 0.8f)] public float characterHeight = 0.62f;
    [Tooltip("Multiplicadores de tamaño por si un personaje se ve muy grande o pequeño")]
    public float johnScale = 1f;
    public float momScale = 1f;
    public float dadScale = 1f;
    public float officerScale = 1f;
    [Tooltip("Marca para voltear la imagen horizontalmente")]
    public bool flipJohn;
    public bool flipMom;
    public bool flipDad;
    public bool flipOfficer;

    [Header("NOMBRES")]
    public string johnName = "John";
    public string momName = "Mamá";
    public string dadName = "Papá";
    public string officerName = "Jefe de la Nasa";

    // ============================================================
    //  USO INTERNO
    // ============================================================
    enum Kind { Dialogue, Letter, Drive }
    enum Place { Home, Road, Nasa }
    enum Who { None, John, Mom, Dad, Officer }

    class Beat
    {
        public Kind kind;
        public Place place;
        public Who[] chars;
        public Who speaker;
        public string text;
        public bool envelope;
    }

    public bool IsPlaying { get; private set; }
    public System.Action OnFinished;

    readonly List<Beat> beats = new List<Beat>();
    int index;
    float typed;
    float beatTime;
    float placeTime;
    Place currentPlace;

    GUIStyle dialogueStyle, captionStyle, nameStyle, hintStyle, hintLeftStyle, centerStyle, bigCenterStyle;
    GUIStyle letterTitle, letterSub, letterBody, skipStyle;

    const float TypeSpeed = 45f; // letras por segundo

    void Awake()
    {
        BuildStory();
    }

    // ------------------------------------------------------------
    //  LA HISTORIA (edita aquí los textos)
    // ------------------------------------------------------------
    void BuildStory()
    {
        beats.Clear();
        Who[] solo = { Who.John };
        Who[] family = { Who.John, Who.Mom, Who.Dad };
        Who[] nasa = { Who.John, Who.Officer };
        Who[] nobody = { };

        // --- La carta ---
        Add(Kind.Dialogue, Place.Home, solo, Who.None,
            "Una mañana cualquiera. John, de 21 años, encuentra una carta en el buzón. El remitente: la NASA.", true);
        Add(Kind.Letter, Place.Home, nobody, Who.None, "");

        // --- En casa ---
        Add(Kind.Dialogue, Place.Home, family, Who.John,
            "¡Mamá, papá! ¡La NASA me convocó para viajar al espacio!");
        Add(Kind.Dialogue, Place.Home, family, Who.Mom,
            "¡Hijo, qué orgullo! Sabía que algún día llegarías muy lejos.");
        Add(Kind.Dialogue, Place.Home, family, Who.Dad,
            "Estudiaste mucho para esto, John. Ve y da lo mejor de ti. ¡Mucha suerte en tu viaje!");
        Add(Kind.Dialogue, Place.Home, family, Who.Mom,
            "Cuídate mucho y llámanos apenas llegues.");
        Add(Kind.Dialogue, Place.Home, family, Who.John,
            "Lo haré. ¡Gracias por todo! Me voy al centro de la NASA.");

        // --- El viaje en auto ---
        Add(Kind.Drive, Place.Road, nobody, Who.None,
            "John conduce hacia el centro espacial de la NASA...");

        // --- En la NASA ---
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.Officer,
            "¡Bienvenido, John! Te estábamos esperando.");
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.Officer,
            "Tu trabajo será diseñar una nave espacial en el Blueprint: elegirás las piezas, el cohete lanzador y la órbita.");
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.Officer,
            "Cada decisión es un equilibrio. Más masa exige un cohete más grande, y los cohetes grandes cuestan más. Y el presupuesto es limitado.");
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.Officer,
            "Después lanzaremos tu nave y veremos si sobrevive a eclipses, tormentas de radiación y fallas durante toda su misión.");
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.Officer,
            "Recuerda: En el espacio no hay margen de error: cada gramo, cada joules y cada decisión cuentan. ¡Manos a la obra!");
        Add(Kind.Dialogue, Place.Nasa, nasa, Who.John,
            "¡Estoy listo!");
    }

    const string LetterText =
        "Estimado John:\n\n" +
        "Usted ha sido seleccionado entre un grupo extraordinariamente competitivo de profesionales destacados de toda la nación. Su historial académico, experiencia técnica y desempeño durante las rigurosas fases de evaluación en el Centro Espacial Johnson han demostrado que posee las cualidades excepcionales que la agencia requiere para el futuro de la exploración espacial humana.\n\n" +
        "Preséntate en nuestro centro de entrenamiento lo antes posible. Tu tarea será diseñar y lanzar una nave " +
        "que cumpla su misión con un presupuesto limitado.\n\n" +
        "¡Bienvenido al programa!\n\n" +
        "Centro Espacial Johnson";

    void Add(Kind kind, Place place, Who[] chars, Who speaker, string text, bool envelope = false)
    {
        beats.Add(new Beat { kind = kind, place = place, chars = chars, speaker = speaker, text = text, envelope = envelope });
    }

    // ------------------------------------------------------------
    //  CONTROL
    // ------------------------------------------------------------
    public void Play()
    {
        if (beats.Count == 0) BuildStory();
        index = 0;
        IsPlaying = true;
        currentPlace = beats[0].place;
        placeTime = 0f;
        EnterBeat();
    }

    public void Skip()
    {
        Finish();
    }

    void Finish()
    {
        IsPlaying = false;
        if (OnFinished != null) OnFinished();
    }

    void EnterBeat()
    {
        Beat b = beats[index];
        typed = (b.kind == Kind.Letter) ? 9999f : 0f;
        beatTime = 0f;
        if (b.place != currentPlace)
        {
            currentPlace = b.place;
            placeTime = 0f; // vuelve a empezar el fundido desde negro
        }
    }

    void Next()
    {
        index++;
        if (index >= beats.Count) { Finish(); return; }
        EnterBeat();
    }

    void Advance()
    {
        Beat b = beats[index];
        if (b.kind == Kind.Dialogue && typed < b.text.Length)
        {
            typed = b.text.Length; // mostrar todo el texto de golpe
            return;
        }
        Next();
    }

    void Update()
    {
        if (!IsPlaying) return;

        float dt = Time.deltaTime;
        beatTime += dt;
        placeTime += dt;
        typed += dt * TypeSpeed;

        if (beats[index].kind == Kind.Drive && beatTime >= driveSeconds)
            Next();
    }

    // ------------------------------------------------------------
    //  DIBUJO (lo llama BlueprintEditor desde su OnGUI)
    // ------------------------------------------------------------
    public void Draw(float w, float h)
    {
        if (!IsPlaying) return;
        InitStyles(h);

        Beat b = beats[index];

        DrawBackground(b, w, h);

        if (b.kind == Kind.Drive)
        {
            DrawDrive(b, w, h);
        }
        else if (b.kind == Kind.Letter)
        {
            DrawLetter(w, h);
        }
        else
        {
            DrawCharacters(b, w, h);
            if (b.envelope) DrawEnvelope(w, h);
            DrawDialogueBox(b, w, h);
        }

        // Fundido desde negro al cambiar de lugar
        float fade = 1f - Mathf.Clamp01(placeTime / 0.7f);
        if (fade > 0.001f) Fill(new Rect(0, 0, w, h), new Color(0f, 0f, 0f, fade));

        // Botón de saltar + entrada de teclado/ratón
        Rect skipRect = new Rect(w - 220f, 12f, 208f, 38f);
        if (GUI.Button(skipRect, "SALTAR HISTORIA", skipStyle))
        {
            Skip();
            return;
        }

        Event e = Event.current;
        if (e.type == EventType.KeyDown &&
            (e.keyCode == KeyCode.Space || e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
        {
            Advance();
            e.Use();
        }
        else if (e.type == EventType.MouseDown && e.button == 0 && !skipRect.Contains(e.mousePosition))
        {
            Advance();
            e.Use();
        }
    }

    void DrawBackground(Beat b, float w, float h)
    {
        Rect full = new Rect(0, 0, w, h);

        if (b.kind == Kind.Drive)
        {
            if (roadBackground != null) GUI.DrawTexture(full, roadBackground, ScaleMode.ScaleAndCrop, true);
            else DrawRoad(w, h);
            return;
        }

        Texture2D bg = (b.place == Place.Nasa) ? nasaBackground : homeBackground;
        if (bg != null)
        {
            GUI.DrawTexture(full, bg, ScaleMode.ScaleAndCrop, true);
        }
        else if (b.place == Place.Nasa)
        {
            Fill(new Rect(0, 0, w, h * 0.72f), new Color(0.35f, 0.55f, 0.85f));
            Fill(new Rect(0, h * 0.72f, w, h * 0.28f), new Color(0.4f, 0.42f, 0.45f));
            Fill(new Rect(w * 0.22f, h * 0.28f, w * 0.56f, h * 0.44f), new Color(0.82f, 0.84f, 0.9f));
            Fill(new Rect(w * 0.20f, h * 0.26f, w * 0.60f, h * 0.03f), new Color(0.6f, 0.65f, 0.75f));
            GUI.Label(new Rect(w * 0.22f, h * 0.28f, w * 0.56f, h * 0.44f), "NASA", bigCenterStyle);
            GUI.Label(new Rect(12f, 12f, w * 0.7f, 30f), "(fondo de ejemplo: arrastra tu imagen a «Nasa Background»)", hintLeftStyle);
        }
        else
        {
            Fill(new Rect(0, 0, w, h * 0.72f), new Color(0.42f, 0.32f, 0.26f));
            Fill(new Rect(0, h * 0.72f, w, h * 0.28f), new Color(0.3f, 0.22f, 0.17f));
            Fill(new Rect(w * 0.08f, h * 0.15f, w * 0.14f, h * 0.22f), new Color(0.6f, 0.8f, 0.95f)); // ventana
            GUI.Label(new Rect(12f, 12f, w * 0.7f, 30f), "(fondo de ejemplo: arrastra tu imagen a «Home Background»)", hintLeftStyle);
        }

        if (b.kind == Kind.Letter) Fill(full, new Color(0f, 0f, 0f, 0.6f));
    }

    // ---------- Personajes ----------

    static float CharX(int i, int n)
    {
        if (n == 1) return 0.5f;
        if (n == 2) return (i == 0) ? 0.3f : 0.7f;
        return 0.2f + 0.3f * i;
    }

    void DrawCharacters(Beat b, float w, float h)
    {
        int n = b.chars.Length;
        bool typing = typed < b.text.Length;

        for (int i = 0; i < n; i++)
        {
            Who who = b.chars[i];
            bool speaking = (who == b.speaker);

            float charH = h * characterHeight * ScaleOf(who);
            float bottom = h * 0.80f;
            float bounce = (speaking && typing) ? Mathf.Abs(Mathf.Sin(Time.time * 12f)) * 7f : 0f; // "habla"
            float breathe = Mathf.Sin(Time.time * 2f + i) * 2f;                                  // respira
            float top = bottom - charH - bounce + breathe;

            Texture2D t = TexOf(who);
            float cw = (t != null) ? charH * t.width / t.height : charH * 0.45f;
            Rect r = new Rect(w * CharX(i, n) - cw / 2f, top, cw, charH);

            bool dim = (b.speaker != Who.None && !speaking);
            Color tint = dim ? new Color(0.65f, 0.65f, 0.72f, 1f) : Color.white;

            if (t != null)
            {
                GUI.color = tint;
                DrawImage(r, t, FlipOf(who));
                GUI.color = Color.white;
            }
            else
            {
                DrawPlaceholderChar(r, who, tint);
            }
        }
    }

    void DrawPlaceholderChar(Rect r, Who who, Color tint)
    {
        Color c = ColorOf(who) * tint;
        c.a = 1f;
        Rect body = new Rect(r.x + r.width * 0.1f, r.y + r.height * 0.36f, r.width * 0.8f, r.height * 0.64f);
        Rect head = new Rect(r.x + r.width * 0.25f, r.y, r.width * 0.5f, r.height * 0.32f);
        Fill(body, c);
        Fill(head, new Color(0.95f, 0.8f, 0.65f) * tint);
        GUI.Label(body, NameOf(who), centerStyle);
    }

    // ---------- Cuadro de diálogo ----------

    void DrawDialogueBox(Beat b, float w, float h)
    {
        Rect box = new Rect(w * 0.05f, h * 0.70f, w * 0.90f, h * 0.30f);

        Fill(new Rect(box.x - 3f, box.y - 3f, box.width + 6f, box.height + 6f), new Color(0.2f, 0.7f, 1f));
        Fill(box, new Color(0.05f, 0.07f, 0.13f, 0.96f));

        // Nombre de quien habla
        Rect chip = new Rect(box.x + 20f, box.y - h * 0.035f, Mathf.Max(w * 0.18f, 150f), h * 0.058f);
        Fill(chip, (b.speaker == Who.None) ? new Color(0.45f, 0.55f, 0.7f) : new Color(1f, 0.55f, 0.15f));
        GUI.Label(chip, NameOf(b.speaker), nameStyle);

        // Texto con efecto de máquina de escribir
        int count = Mathf.Clamp(Mathf.FloorToInt(typed), 0, b.text.Length);
        GUI.Label(new Rect(box.x + 24f, box.y + h * 0.03f, box.width - 48f, box.height - h * 0.04f),
                  b.text.Substring(0, count), dialogueStyle);

        if (typed >= b.text.Length)
        {
            float a = 0.5f + 0.5f * Mathf.Sin(Time.time * 4f);
            GUI.color = new Color(1f, 1f, 1f, a);
            GUI.Label(new Rect(box.x, box.yMax - 30f, box.width - 20f, 26f), "ESPACIO o CLIC para continuar", hintStyle);
            GUI.color = Color.white;
        }
    }

    // ---------- Sobre ----------

    void DrawEnvelope(float w, float h)
    {
        float size = h * 0.24f;
        float bob = Mathf.Sin(Time.time * 2f) * 6f;

        if (letter != null)
        {
            float lw = size * letter.width / letter.height;
            GUI.DrawTexture(new Rect(w * 0.72f - lw / 2f, h * 0.36f + bob, lw, size), letter, ScaleMode.StretchToFill, true);
            return;
        }

        Rect r = new Rect(w * 0.72f - size * 0.7f, h * 0.36f + bob, size * 1.4f, size * 0.9f);
        Fill(r, new Color(0.95f, 0.92f, 0.82f));
        Fill(new Rect(r.x, r.y, r.width, r.height * 0.09f), new Color(0.1f, 0.25f, 0.6f));
        GUI.Label(r, "NASA", centerStyle);
    }

    // ---------- Carta ----------

    void DrawLetter(float w, float h)
    {
        float k = Mathf.Clamp01(beatTime / 0.6f);
        float ease = 1f - (1f - k) * (1f - k);

        float pw = Mathf.Min(w * 0.62f, h * 1.05f);
        float ph = h * 0.74f;
        Rect paper = new Rect((w - pw) / 2f, h * 0.10f + (1f - ease) * h * 0.15f, pw, ph);

        Fill(new Rect(paper.x + 8f, paper.y + 8f, paper.width, paper.height), new Color(0f, 0f, 0f, 0.4f * ease));
        Fill(paper, new Color(0.96f, 0.93f, 0.84f, ease));
        Fill(new Rect(paper.x, paper.y, paper.width, 12f), new Color(0.1f, 0.25f, 0.6f, ease));

        GUI.color = new Color(1f, 1f, 1f, ease);
        GUI.Label(new Rect(paper.x + 30f, paper.y + 26f, paper.width - 60f, h * 0.10f), "NASA", letterTitle);
        GUI.Label(new Rect(paper.x + 30f, paper.y + 26f + h * 0.09f, paper.width - 60f, h * 0.05f), "Centro Espacial - Dirección de Misiones", letterSub);
        GUI.Label(new Rect(paper.x + 36f, paper.y + 26f + h * 0.16f, paper.width - 72f, paper.height - h * 0.20f), LetterText, letterBody);

        float a = 0.5f + 0.5f * Mathf.Sin(Time.time * 4f);
        GUI.color = new Color(1f, 1f, 1f, a * ease);
        GUI.Label(new Rect(0f, h - 44f, w - 24f, 30f), "ESPACIO o CLIC para continuar", hintStyle);
        GUI.color = Color.white;
    }

    // ---------- Viaje en auto ----------

    void DrawRoad(float w, float h)
    {
        Fill(new Rect(0, 0, w, h * 0.58f), new Color(0.45f, 0.72f, 0.95f));       // cielo
        Fill(new Rect(0, h * 0.50f, w, h * 0.10f), new Color(0.30f, 0.55f, 0.40f)); // colinas
        Fill(new Rect(0, h * 0.58f, w, h * 0.42f), new Color(0.28f, 0.55f, 0.28f)); // pasto
        Fill(new Rect(0, h * 0.66f, w, h * 0.26f), new Color(0.22f, 0.22f, 0.26f)); // camino
        Fill(new Rect(0, h * 0.66f, w, 4f), Color.white);
        Fill(new Rect(0, h * 0.92f - 4f, w, 4f), Color.white);

        // Líneas del centro que se mueven hacia atrás (da sensación de velocidad)
        float period = 130f;
        float offset = (beatTime * 600f) % period;
        float y = h * 0.79f;
        for (float x = -offset; x < w; x += period)
            Fill(new Rect(x, y, 70f, 8f), Color.white);
    }

    void DrawDrive(Beat b, float w, float h)
    {
        float t01 = Mathf.Clamp01(beatTime / Mathf.Max(0.1f, driveSeconds));
        float eased = Mathf.SmoothStep(0f, 1f, t01);

        float carH = h * 0.24f;
        float carW = (car != null) ? carH * car.width / car.height : carH * 2f;
        float x = Mathf.Lerp(-carW, w, eased);
        float bob = Mathf.Sin(Time.time * 18f) * 2.5f;
        Rect r = new Rect(x, h * carBottom - carH + bob, carW, carH);

        if (car != null) DrawImage(r, car, !carFacesRight);
        else DrawPlaceholderCar(r);

        // Texto arriba
        Rect box = new Rect(w * 0.15f, h * 0.06f, w * 0.70f, h * 0.11f);
        Fill(new Rect(box.x - 3f, box.y - 3f, box.width + 6f, box.height + 6f), new Color(0.2f, 0.7f, 1f));
        Fill(box, new Color(0.05f, 0.07f, 0.13f, 0.9f));
        int count = Mathf.Clamp(Mathf.FloorToInt(typed), 0, b.text.Length);
        GUI.Label(box, b.text.Substring(0, count), captionStyle);

        GUI.Label(new Rect(0f, h - 44f, w - 24f, 30f), "CLIC para saltar el viaje", hintStyle);
    }

    void DrawPlaceholderCar(Rect r)
    {
        Fill(new Rect(r.x + r.width * 0.05f, r.y + r.height * 0.40f, r.width * 0.90f, r.height * 0.38f), new Color(0.85f, 0.2f, 0.2f));
        Fill(new Rect(r.x + r.width * 0.25f, r.y + r.height * 0.12f, r.width * 0.45f, r.height * 0.30f), new Color(0.75f, 0.15f, 0.15f));
        Fill(new Rect(r.x + r.width * 0.30f, r.y + r.height * 0.18f, r.width * 0.35f, r.height * 0.18f), new Color(0.7f, 0.85f, 0.95f));
        float wheel = r.height * 0.26f;
        Fill(new Rect(r.x + r.width * 0.15f, r.y + r.height * 0.68f, wheel, wheel), new Color(0.1f, 0.1f, 0.1f));
        Fill(new Rect(r.x + r.width * 0.68f, r.y + r.height * 0.68f, wheel, wheel), new Color(0.1f, 0.1f, 0.1f));
    }

    // ---------- Utilidades de dibujo ----------

    static void Fill(Rect r, Color c)
    {
        GUI.color = c;
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = Color.white;
    }

    static void DrawImage(Rect r, Texture2D t, bool flip)
    {
        if (flip) GUI.DrawTextureWithTexCoords(r, t, new Rect(1f, 0f, -1f, 1f));
        else GUI.DrawTexture(r, t, ScaleMode.StretchToFill, true);
    }

    Texture2D TexOf(Who who)
    {
        switch (who)
        {
            case Who.John: return john;
            case Who.Mom: return mom;
            case Who.Dad: return dad;
            case Who.Officer: return officer;
            default: return null;
        }
    }

    float ScaleOf(Who who)
    {
        switch (who)
        {
            case Who.John: return johnScale;
            case Who.Mom: return momScale;
            case Who.Dad: return dadScale;
            case Who.Officer: return officerScale;
            default: return 1f;
        }
    }

    bool FlipOf(Who who)
    {
        switch (who)
        {
            case Who.John: return flipJohn;
            case Who.Mom: return flipMom;
            case Who.Dad: return flipDad;
            case Who.Officer: return flipOfficer;
            default: return false;
        }
    }

    string NameOf(Who who)
    {
        switch (who)
        {
            case Who.John: return johnName;
            case Who.Mom: return momName;
            case Who.Dad: return dadName;
            case Who.Officer: return officerName;
            default: return "NARRADOR";
        }
    }

    static Color ColorOf(Who who)
    {
        switch (who)
        {
            case Who.John: return new Color(0.2f, 0.45f, 0.85f);
            case Who.Mom: return new Color(0.8f, 0.4f, 0.5f);
            case Who.Dad: return new Color(0.35f, 0.6f, 0.4f);
            case Who.Officer: return new Color(0.85f, 0.65f, 0.2f);
            default: return Color.gray;
        }
    }

    void InitStyles(float h)
    {
        if (dialogueStyle == null)
        {
            dialogueStyle = new GUIStyle(GUI.skin.label) { wordWrap = true };
            dialogueStyle.normal.textColor = Color.white;

            captionStyle = new GUIStyle(dialogueStyle) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };

            nameStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            nameStyle.normal.textColor = new Color(0.05f, 0.07f, 0.13f);

            hintStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.LowerRight };
            hintStyle.normal.textColor = new Color(0.6f, 0.85f, 1f);

            hintLeftStyle = new GUIStyle(GUI.skin.label) { fontSize = 13 };
            hintLeftStyle.normal.textColor = new Color(1f, 1f, 1f, 0.6f);

            centerStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, wordWrap = true };
            centerStyle.normal.textColor = Color.white;

            bigCenterStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
            bigCenterStyle.normal.textColor = new Color(0.1f, 0.25f, 0.6f);

            letterTitle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold };
            letterTitle.normal.textColor = new Color(0.1f, 0.25f, 0.6f);

            letterSub = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Italic };
            letterSub.normal.textColor = new Color(0.3f, 0.3f, 0.35f);

            letterBody = new GUIStyle(GUI.skin.label) { wordWrap = true };
            letterBody.normal.textColor = new Color(0.15f, 0.15f, 0.18f);

            skipStyle = new GUIStyle(GUI.skin.button) { fontSize = 16 };
        }

        // Los tamaños de letra se adaptan al alto de la pantalla
        dialogueStyle.fontSize = Mathf.Max(16, Mathf.RoundToInt(h * 0.032f));
        captionStyle.fontSize = Mathf.Max(18, Mathf.RoundToInt(h * 0.036f));
        nameStyle.fontSize = Mathf.Max(15, Mathf.RoundToInt(h * 0.028f));
        centerStyle.fontSize = Mathf.Max(14, Mathf.RoundToInt(h * 0.026f));
        bigCenterStyle.fontSize = Mathf.Max(30, Mathf.RoundToInt(h * 0.11f));
        letterTitle.fontSize = Mathf.Max(28, Mathf.RoundToInt(h * 0.07f));
        letterSub.fontSize = Mathf.Max(14, Mathf.RoundToInt(h * 0.026f));
        letterBody.fontSize = Mathf.Max(15, Mathf.RoundToInt(h * 0.029f));
    }
}
