using UnityEngine;

[CreateAssetMenu(fileName = "NewOrbit", menuName = "Orbital Trade-Off/Orbit")]
public class OrbitData : ScriptableObject
{
    public string orbitName = "Nueva órbita";
    [Tooltip("Altura sobre la superficie en km")]
    public float altitudeKm = 400f;
    [Tooltip("ΔV (m/s) que el satélite debe poder generar con su propio combustible para llegar aquí")]
    public float deltaVRequired = 100f;
}
