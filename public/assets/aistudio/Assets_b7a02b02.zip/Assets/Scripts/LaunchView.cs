using UnityEngine;

public enum LaunchOutcome { Idle, Running, LaunchFailed, OrbitFailed, Success }

// Vista lateral 2D del lanzamiento. Todo se dibuja por código.
// BlueprintEditor lo agrega solo a la escena.
public class LaunchView : MonoBehaviour
{
    enum Stage { Countdown, Ascent, Falling, Exploded, Circularizing }

    const float CountdownSeconds = 3f;
    const float AscentSeconds = 12f;
    const float CircSeconds = 4f;
    const float SeparationP = 0.45f;   // en qué punto del ascenso se separa la etapa 1
    const float Gravity = 8f;          // gravedad visual (unidades/s²)
    const float PadTop = 0.4f;         // altura de la plataforma
    const float UnitsPerKm = 0.2f;     // escala visual: 200 km = 40 unidades

    // La escena de lanzamiento está lejos del mapa orbital para que no se mezclen.
    static readonly Vector2 Origin = new Vector2(5000f, 0f);
    static readonly Color SkyColor = new Color(0.35f, 0.6f, 0.9f);
    static readonly Color SpaceColor = new Color(0.03f, 0.04f, 0.08f);

    // Datos que lee la interfaz
    public LaunchOutcome Outcome { get; private set; }
    public string Phase { get; private set; }
    public string ResultMessage { get; private set; }
    public float AltitudeKm { get; private set; }
    public float SpeedKms { get; private set; }
    public float DeltaVBurned { get; private set; }
    public float DeltaVRequired { get; private set; }

    // BlueprintEditor lo activa solo cuando la pestaña de lanzamiento está abierta.
    public bool ViewActive
    {
        get { return viewActive; }
        set
        {
            if (viewActive && !value && cam != null) cam.backgroundColor = SpaceColor;
            viewActive = value;
            if (backdropRoot != null) backdropRoot.gameObject.SetActive(value);
            if (mapView == null) mapView = GetComponent<OrbitMapView>();
            if (mapView != null) mapView.SetBackdropVisible(!value);
        }
    }

    bool viewActive;
    Camera cam;
    GameObject root;
    Sprite circleSprite, squareSprite;

    GameVisuals vis;
    OrbitMapView mapView;
    Transform backdropRoot;
    SpriteRenderer skyBack, spaceBack;
    float skyAspect = 1f, spaceAspect = 1f;
    bool flameTextured;

    Transform rocketRoot, stage1, stage2;
    SpriteRenderer flame1, flame2, explosion;
    Transform detachedStage1;
    Transform fairingPart, detachedFairing;
    Vector2 fairingVel;
    float fairingSpin;
    bool fairingFalling;

    float flame1BaseY = 0f, flame1Height = 1.4f, flame1Width = 1.0f;
    float flame2BaseY = 1.85f, flame2Height = 0.8f, flame2Width = 0.5f;

    Stage stage;
    MissionResult res;
    string orbitName;
    float rocketScale = 1f;
    float t, tCirc;
    bool willFailLaunch, willFailOrbit, separated;
    float failP;
    Vector2 lastVelocity;
    Vector2 fallVel, detVel;
    float spin, detSpin;
    bool detachedFalling;
    bool explosionActive;
    float explosionT;
    Vector3 explosionPos = new Vector3(Origin.x, PadTop, 0f);

    static Vector3 PadPosition { get { return new Vector3(Origin.x, PadTop, 0f); } }

    void Awake()
    {
        vis = GetComponent<GameVisuals>();
        if (vis == null) vis = gameObject.AddComponent<GameVisuals>();
#if UNITY_EDITOR
        vis.AutoAssignDefaults();
#endif
        mapView = GetComponent<OrbitMapView>();

        cam = Camera.main;
        circleSprite = MakeCircleSprite();
        squareSprite = MakeSquareSprite();
        root = new GameObject("Lanzamiento");
        BuildBackdrop();
        BuildStaticScene();

        explosion = MakePart(root.transform, "Explosion", circleSprite, Color.white, Vector3.zero, Vector3.one, 8);
        explosion.enabled = false;

        Outcome = LaunchOutcome.Idle;
        Phase = "Listo para lanzar";
        ResultMessage = "";
    }

    void OnDestroy()
    {
        if (root != null) Destroy(root);
        if (backdropRoot != null) Destroy(backdropRoot.gameObject);
    }

    // ---------- API pública ----------

    // Deja el cohete en la plataforma, listo para lanzar. No hace nada si hay un lanzamiento en curso.
    public void Prepare(float launcherCapacityKg)
    {
        if (Outcome == LaunchOutcome.Running) return;

        Outcome = LaunchOutcome.Idle;
        Phase = "Listo para lanzar";
        ResultMessage = "";
        AltitudeKm = 0f;
        SpeedKms = 0f;
        DeltaVBurned = 0f;
        stage = Stage.Countdown;
        explosionActive = false;
        if (explosion != null) explosion.enabled = false;
        explosionPos = PadPosition;
        BuildRocket(launcherCapacityKg);
    }

    public void StartLaunch(MissionResult result, string targetOrbitName)
    {
        if (Outcome != LaunchOutcome.Idle || result == null) return;

        res = result;
        orbitName = targetOrbitName;
        DeltaVRequired = result.deltaVRequired;
        DeltaVBurned = 0f;

        willFailLaunch = result.totalMassKg > result.launcherCapacityKg;
        float k = (result.totalMassKg > 0f) ? Mathf.Min(1f, result.launcherCapacityKg / result.totalMassKg) : 0f;
        // Cuanto más sobrepeso, antes falla (entre el 20 % y el 92 % del ascenso)
        failP = Mathf.Lerp(0.2f, 0.92f, Mathf.InverseLerp(0.4f, 1f, k));
        willFailOrbit = !willFailLaunch && result.deltaVAvailable < result.deltaVRequired;

        t = 0f;
        separated = false;
        stage = Stage.Countdown;
        Outcome = LaunchOutcome.Running;
        Phase = "Cuenta regresiva";
    }

    // ---------- Simulación ----------

    void Update()
    {
        float dt = Time.deltaTime;
        UpdateDetachedStage(dt);
        UpdateExplosion(dt);

        if (Outcome != LaunchOutcome.Running || rocketRoot == null) return;

        t += dt;
        switch (stage)
        {
            case Stage.Countdown: UpdateCountdown(); break;
            case Stage.Ascent: UpdateAscent(); break;
            case Stage.Falling: UpdateFalling(dt); break;
            case Stage.Circularizing: UpdateCirc(dt); break;
        }
        AnimateFlames();
    }

    void UpdateCountdown()
    {
        float remaining = CountdownSeconds - t;
        Phase = "Cuenta regresiva: T-" + Mathf.CeilToInt(Mathf.Max(remaining, 0f));
        if (remaining <= 1f)
        {
            flame1.enabled = true;
            rocketRoot.position = PadPosition + new Vector3(Random.Range(-0.03f, 0.03f), 0f, 0f); // vibración
        }
        if (remaining <= 0f) stage = Stage.Ascent;
    }

    void UpdateAscent()
    {
        float p = Mathf.Clamp01((t - CountdownSeconds) / AscentSeconds);
        float pEnd = willFailLaunch ? failP : 1f;

        if (p >= pEnd)
        {
            MoveRocket(pEnd);
            if (willFailLaunch)
            {
                stage = Stage.Falling;
                fallVel = lastVelocity;
                spin = Random.Range(-70f, 70f);
                flame1.enabled = false;
                flame2.enabled = false;
                Phase = "¡Pérdida de empuje!";
            }
            else
            {
                stage = Stage.Circularizing;
                tCirc = t;
                Phase = "Quemado de circularización";
            }
            return;
        }

        MoveRocket(p);
        if (!separated && p >= SeparationP) Separate();

        if (!separated) Phase = "Etapa 1 encendida";
        else if (t - (CountdownSeconds + SeparationP * AscentSeconds) < 1.2f) Phase = "Separación de etapas";
        else Phase = "Etapa 2 encendida";
    }

    void UpdateFalling(float dt)
    {
        fallVel.y -= Gravity * dt;
        rocketRoot.position += new Vector3(fallVel.x, fallVel.y, 0f) * dt;
        rocketRoot.Rotate(0f, 0f, spin * dt);
        AltitudeKm = Mathf.Max(0f, (rocketRoot.position.y - PadTop) / UnitsPerKm);
        SpeedKms = Mathf.Max(0f, SpeedKms - 2f * dt);

        if (rocketRoot.position.y <= PadTop) Explode(rocketRoot.position);
    }

    void UpdateCirc(float dt)
    {
        float q = (t - tCirc) / CircSeconds;
        float req = Mathf.Max(res.deltaVRequired, 0.0001f);
        float qEnd = willFailOrbit ? Mathf.Clamp01(res.deltaVAvailable / req) : 1f;

        DeltaVBurned = Mathf.Min(q, qEnd) * res.deltaVRequired;
        flame2.enabled = q < qEnd;
        rocketRoot.position += rocketRoot.up * (1.2f * dt);

        if (willFailOrbit)
        {
            if (q >= qEnd) Phase = "¡Combustible agotado!";
            if (q >= qEnd + 0.35f) Finish(LaunchOutcome.OrbitFailed);
        }
        else if (q >= 1f)
        {
            Finish(LaunchOutcome.Success);
        }
    }

    void Finish(LaunchOutcome outcome)
    {
        Outcome = outcome;
        flame2.enabled = false;
        if (outcome == LaunchOutcome.Success)
        {
            DeltaVBurned = res.deltaVRequired;
            Phase = "¡Órbita alcanzada!";
            ResultMessage = "¡Órbita " + orbitName + " alcanzada! Te sobraron " +
                            (res.deltaVAvailable - res.deltaVRequired).ToString("F0") + " m/s de ΔV.";
        }
        else
        {
            Phase = "Órbita fallida";
            ResultMessage = "ΔV insuficiente: tu nave tiene " + res.deltaVAvailable.ToString("F0") +
                            " m/s y necesitaba " + res.deltaVRequired.ToString("F0") + " m/s para la órbita " + orbitName +
                            ". Se queda atrapada en una órbita de transferencia. Agrega combustible, pero ojo: sube la masa.";
        }
    }

    void Explode(Vector3 pos)
    {
        explosionPos = new Vector3(pos.x, Mathf.Max(pos.y, PadTop), 0f);
        explosion.transform.position = explosionPos;
        explosion.enabled = true;
        explosionActive = true;
        explosionT = 0f;
        rocketRoot.gameObject.SetActive(false);

        stage = Stage.Exploded;
        Outcome = LaunchOutcome.LaunchFailed;
        Phase = "Falla de lanzamiento";
        ResultMessage = "Falla de lanzamiento: la masa total (" + res.totalMassKg.ToString("F0") +
                        " kg) supera la capacidad del lanzador (" + res.launcherCapacityKg.ToString("F0") +
                        " kg). El cohete no alcanzó la velocidad necesaria y cayó. Usa un lanzador más grande o quita masa.";
    }

    // ---------- Movimiento ----------

    // Trayectoria visual: sube y se inclina poco a poco hacia la derecha.
    static Vector2 PathPos(float p)
    {
        float y = 200f * UnitsPerKm * Mathf.Pow(p, 1.8f);
        float x = 0.5f * y * p;
        return new Vector2(x, y);
    }

    void MoveRocket(float p)
    {
        Vector2 pos = PathPos(p);
        Vector2 d = (PathPos(Mathf.Min(1f, p + 0.002f)) - PathPos(Mathf.Max(0f, p - 0.002f))) / 0.004f;
        float ang = (d.sqrMagnitude > 0.0001f) ? -Mathf.Atan2(d.x, d.y) * Mathf.Rad2Deg : 0f;

        rocketRoot.position = new Vector3(Origin.x + pos.x, PadTop + pos.y, 0f);
        rocketRoot.rotation = Quaternion.Euler(0f, 0f, ang);

        lastVelocity = d / AscentSeconds; // unidades por segundo
        AltitudeKm = 200f * Mathf.Pow(p, 1.8f);
        SpeedKms = 7.8f * Mathf.Pow(p, 1.1f);
    }

    void Separate()
    {
        separated = true;
        flame1.enabled = false;
        flame2.enabled = true;

        detachedStage1 = stage1;
        stage1.SetParent(root.transform, true); // conserva su posición en el mundo
        detVel = lastVelocity * 0.6f;
        detSpin = 50f;
        detachedFalling = true;

        if (fairingPart != null)
        {
            detachedFairing = fairingPart;
            fairingPart.SetParent(root.transform, true);
            fairingVel = lastVelocity * 0.7f + new Vector2(1.5f, 0.5f);
            fairingSpin = -40f;
            fairingFalling = true;
            fairingPart = null;
        }
    }

    void UpdateDetachedStage(float dt)
    {
        if (detachedFalling && detachedStage1 != null)
        {
            detVel.y -= Gravity * dt;
            detachedStage1.position += new Vector3(detVel.x, detVel.y, 0f) * dt;
            detachedStage1.Rotate(0f, 0f, detSpin * dt);
            if (detachedStage1.position.y <= 0.3f)
            {
                detachedStage1.gameObject.SetActive(false);
                detachedFalling = false;
            }
        }

        if (fairingFalling && detachedFairing != null)
        {
            fairingVel.y -= Gravity * dt;
            detachedFairing.position += new Vector3(fairingVel.x, fairingVel.y, 0f) * dt;
            detachedFairing.Rotate(0f, 0f, fairingSpin * dt);
            if (detachedFairing.position.y <= 0.3f)
            {
                detachedFairing.gameObject.SetActive(false);
                fairingFalling = false;
            }
        }
    }

    void UpdateExplosion(float dt)
    {
        if (!explosionActive) return;
        explosionT += dt;
        float k = Mathf.Clamp01(explosionT / 0.9f);
        explosion.transform.localScale = Vector3.one * Mathf.Lerp(0.5f, 7f, k);
        explosion.color = new Color(1f, Mathf.Lerp(0.7f, 0.25f, k), 0.1f, 1f - k);
        if (k >= 1f)
        {
            explosion.enabled = false;
            explosionActive = false;
        }
    }

    void AnimateFlames()
    {
        float n = 0.85f + 0.3f * Mathf.PerlinNoise(Time.time * 20f, 0f);
        SetFlame(flame1, flame1BaseY, flame1Width, flame1Height * n);
        SetFlame(flame2, flame2BaseY, flame2Width, flame2Height * n);
    }

    void SetFlame(SpriteRenderer f, float baseY, float width, float height)
    {
        if (f == null || !f.enabled) return;
        bool hasTex = (f.sprite != null && f.sprite != squareSprite);
        f.transform.localScale = hasTex ? new Vector3(height, height, 1f) : new Vector3(width, height, 1f);
        f.transform.localPosition = new Vector3(0f, baseY - height / 2f, 0f);
    }

    // La cámara sigue al cohete y el cielo se oscurece con la altura.
    void LateUpdate()
    {
        if (!viewActive || cam == null) return;

        Vector3 focus = (rocketRoot != null && rocketRoot.gameObject.activeSelf) ? rocketRoot.position : explosionPos;
        cam.orthographic = true;
        cam.orthographicSize = 7f;
        cam.transform.position = new Vector3(focus.x, Mathf.Max(focus.y + 2f, 4f), -10f);
        cam.backgroundColor = Color.Lerp(SkyColor, SpaceColor, Mathf.Clamp01(AltitudeKm / 80f));
        UpdateBackdrop();
    }

    // ---------- Construcción de la escena ----------

    // Fondos pegados a la cámara: cielo de día y espacio (se mezclan según la altura)
    void BuildBackdrop()
    {
        if (cam == null) return;

        backdropRoot = new GameObject("FondoLanzamiento").transform;
        backdropRoot.SetParent(cam.transform, false);
        backdropRoot.localPosition = new Vector3(0f, 0f, 40f);

        if (vis.launchSpace != null)
        {
            spaceBack = MakeBackdropSprite("Espacio", vis.launchSpace, -20);
            spaceAspect = vis.launchSpace.width / (float)vis.launchSpace.height;
        }
        if (vis.launchSky != null)
        {
            skyBack = MakeBackdropSprite("Cielo", vis.launchSky, -19);
            skyAspect = vis.launchSky.width / (float)vis.launchSky.height;
        }

        backdropRoot.gameObject.SetActive(false); // se muestra solo en la pestaña de lanzamiento
    }

    SpriteRenderer MakeBackdropSprite(string objName, Texture2D tex, int order)
    {
        var go = new GameObject(objName);
        go.transform.SetParent(backdropRoot, false);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = GameVisuals.MakeSprite(tex);
        sr.sortingOrder = order;
        return sr;
    }

    void UpdateBackdrop()
    {
        if (backdropRoot == null || cam == null) return;

        float viewH = cam.orthographicSize * 2f;
        float viewW = viewH * cam.aspect;
        float k = Mathf.Clamp01(AltitudeKm / 80f);

        if (spaceBack != null)
        {
            float sc = Mathf.Max(viewH, viewW / spaceAspect);
            spaceBack.transform.localScale = new Vector3(sc, sc, 1f);
            // Si no hay cielo, el espacio aparece poco a poco al subir
            spaceBack.color = new Color(1f, 1f, 1f, (skyBack != null) ? 1f : k);
        }
        if (skyBack != null)
        {
            float sc = Mathf.Max(viewH, viewW / skyAspect);
            skyBack.transform.localScale = new Vector3(sc, sc, 1f);
            skyBack.color = new Color(1f, 1f, 1f, 1f - k);
        }
    }

    void BuildStaticScene()
    {
        Transform r = root.transform;

        // Suelo: con textura se repite a lo largo
        if (vis.ground != null)
        {
            var go = new GameObject("Suelo");
            go.transform.SetParent(r, false);
            go.transform.position = new Vector3(Origin.x, -10f, 0f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = GameVisuals.MakeTiledSprite(vis.ground, 4f);
            sr.drawMode = SpriteDrawMode.Tiled;
            sr.size = new Vector2(400f, 20f);
            sr.sortingOrder = 1;
        }
        else
        {
            MakePart(r, "Suelo", squareSprite, new Color(0.22f, 0.42f, 0.2f), new Vector3(Origin.x, -10f, 0f), new Vector3(400f, 20f, 1f), 1);
        }

        // Plataforma
        if (vis.launchPad != null)
            MakeTexturedPart(r, "Plataforma", vis.launchPad, new Vector3(Origin.x, 0.2f, 0f), 0.4f, 2);
        else
            MakePart(r, "Plataforma", squareSprite, new Color(0.45f, 0.45f, 0.5f), new Vector3(Origin.x, 0.2f, 0f), new Vector3(3.2f, 0.4f, 1f), 2);

        MakePart(r, "Torre", squareSprite, new Color(0.3f, 0.3f, 0.35f), new Vector3(Origin.x - 2f, 3.4f, 0f), new Vector3(0.3f, 6.4f, 1f), 2);

        var rng = new System.Random(7);

        // Nubes
        for (int i = 0; i < 7; i++)
        {
            float x = Origin.x + (float)(rng.NextDouble() * 80.0 - 40.0);
            float y = 3f + (float)(rng.NextDouble() * 6.0);
            float sx = 3f + (float)(rng.NextDouble() * 4.0);
            if (vis.cloud != null)
            {
                var c = MakeTexturedPart(r, "Nube", vis.cloud, new Vector3(x, y, 0f), sx * 0.45f, 0);
                c.color = new Color(1f, 1f, 1f, 0.9f);
            }
            else
            {
                MakePart(r, "Nube", circleSprite, new Color(1f, 1f, 1f, 0.75f), new Vector3(x, y, 0f), new Vector3(sx, sx * 0.3f, 1f), 0);
            }
        }

        // Estrellas
        for (int i = 0; i < 80; i++)
        {
            float x = Origin.x + (float)(rng.NextDouble() * 140.0 - 60.0);
            float y = 14f + (float)(rng.NextDouble() * 90.0);
            float s = 0.08f + (float)(rng.NextDouble() * 0.12);
            if (vis.star != null)
            {
                var st = MakeTexturedPart(r, "Estrella", vis.star, new Vector3(x, y, 0f), s * 3f, -5);
                st.color = new Color(1f, 1f, 1f, 0.9f);
            }
            else
            {
                MakePart(r, "Estrella", circleSprite, new Color(1f, 1f, 1f, 0.9f), new Vector3(x, y, 0f), new Vector3(s, s, 1f), -5);
            }
        }
    }

    void BuildRocket(float capacityKg)
    {
        if (rocketRoot != null) Destroy(rocketRoot.gameObject);
        if (detachedStage1 != null) Destroy(detachedStage1.gameObject);
        if (detachedFairing != null) Destroy(detachedFairing.gameObject);
        detachedStage1 = null;
        detachedFairing = null;
        fairingPart = null;
        detachedFalling = false;
        fairingFalling = false;
        separated = false;

#if UNITY_EDITOR
        if (vis != null) vis.AutoAssignDefaults();
#endif

        // Identificar el diseño según la capacidad del lanzador:
        // Pequeño  -> Lanzador Ligero (500 kg, <= 800)
        // Mediano  -> Lanzador Medio  (1200 kg, 801..1600)
        // Grande   -> Lanzador Pesado (2000 kg, > 1600)
        bool isLight = capacityKg <= 800f;
        bool isMedium = capacityKg > 800f && capacityKg <= 1600f;

        Texture2D texStage1 = null;
        Texture2D texStage2 = null;
        Texture2D texFlame1 = null;
        Texture2D texFlame2 = null;
        Texture2D texFairing = null;

        float s1H = 2.1f;
        float s1Y = 1.05f;
        float s2H = 2.0f;
        float s2Y = 2.95f;
        flame1BaseY = 0f;
        flame1Height = 1.4f;
        flame1Width = 1.0f;
        flame2BaseY = 1.95f;
        flame2Height = 0.8f;
        flame2Width = 0.5f;

        if (isLight)
        {
            texStage1 = (vis != null && vis.rocketLightStage1 != null) ? vis.rocketLightStage1 : (vis != null ? vis.rocketStage1 : null);
            texStage2 = (vis != null && vis.rocketLightStage2 != null) ? vis.rocketLightStage2 : (vis != null ? vis.rocketStage2 : null);
            texFlame1 = (vis != null && vis.rocketLightFlame != null) ? vis.rocketLightFlame : (vis != null ? vis.rocketFlame : null);
            texFlame2 = texFlame1;

            s1H = 2.1f;
            s1Y = 1.05f;
            s2H = 2.0f;
            s2Y = 2.95f;
            flame1BaseY = 0f;
            flame1Height = 1.4f;
            flame1Width = 1.0f;
            flame2BaseY = 1.95f;
            flame2Height = 0.8f;
            flame2Width = 0.5f;
            rocketScale = 0.9f;
        }
        else if (isMedium)
        {
            texStage1 = (vis != null && vis.rocketMediumStage1 != null) ? vis.rocketMediumStage1 : (vis != null ? vis.rocketStage1 : null);
            texStage2 = (vis != null && vis.rocketMediumStage2 != null) ? vis.rocketMediumStage2 : (vis != null ? vis.rocketStage2 : null);
            texFlame1 = (vis != null && vis.rocketMediumFlame != null) ? vis.rocketMediumFlame : (vis != null ? vis.rocketFlame : null);
            texFlame2 = (vis != null && vis.rocketLightFlame != null) ? vis.rocketLightFlame : (vis != null ? vis.rocketFlame : null);

            s1H = 2.3f;
            s1Y = 1.15f;
            s2H = 2.4f;
            s2Y = 3.2f;
            flame1BaseY = 0f;
            flame1Height = 1.8f;
            flame1Width = 1.8f;
            flame2BaseY = 2.0f;
            flame2Height = 0.9f;
            flame2Width = 0.6f;
            rocketScale = 1.1f;
        }
        else // Heavy
        {
            texStage1 = (vis != null && vis.rocketHeavyStage1 != null) ? vis.rocketHeavyStage1 : (vis != null ? vis.rocketStage1 : null);
            texStage2 = (vis != null && vis.rocketHeavyStage2 != null) ? vis.rocketHeavyStage2 : (vis != null ? vis.rocketStage2 : null);
            texFairing = (vis != null && vis.rocketHeavyFairing != null) ? vis.rocketHeavyFairing : (vis != null ? vis.rocketPayload : null);
            texFlame1 = (vis != null && vis.rocketHeavyFlame != null) ? vis.rocketHeavyFlame : (vis != null ? vis.rocketFlame : null);
            texFlame2 = (vis != null && vis.rocketLightFlame != null) ? vis.rocketLightFlame : (vis != null ? vis.rocketFlame : null);

            s1H = 3.4f;
            s1Y = 1.7f;
            s2H = 2.3f;
            s2Y = 4.25f;
            flame1BaseY = 0f;
            flame1Height = 2.5f;
            flame1Width = 2.2f;
            flame2BaseY = 3.1f;
            flame2Height = 1.1f;
            flame2Width = 0.7f;
            rocketScale = 1.35f;
        }

        flameTextured = (texFlame1 != null);

        rocketRoot = new GameObject("Cohete").transform;
        rocketRoot.SetParent(root.transform, false);
        rocketRoot.position = PadPosition;

        // Etapa 1: propulsor grande + llama
        stage1 = new GameObject("Etapa1").transform;
        stage1.SetParent(rocketRoot, false);
        if (texStage1 != null)
            MakeTexturedPart(stage1, "Cuerpo", texStage1, new Vector3(0f, s1Y, 0f), s1H, 5);
        else
            MakePart(stage1, "Cuerpo", squareSprite, new Color(0.92f, 0.92f, 0.96f), new Vector3(0f, s1Y, 0f), new Vector3(0.9f * rocketScale, s1H, 1f), 5);

        if (texFlame1 != null)
            flame1 = MakeTexturedPart(stage1, "Llama", texFlame1, new Vector3(0f, flame1BaseY - flame1Height / 2f, 0f), flame1Height, 4);
        else
            flame1 = MakePart(stage1, "Llama", squareSprite, new Color(1f, 0.55f, 0.1f), new Vector3(0f, flame1BaseY - flame1Height / 2f, 0f), new Vector3(flame1Width, flame1Height, 1f), 4);
        flame1.enabled = false;

        // Etapa 2: cuerpo superior / cápsula + cofia (opcional) + llama
        stage2 = new GameObject("Etapa2").transform;
        stage2.SetParent(rocketRoot, false);
        if (texStage2 != null)
            MakeTexturedPart(stage2, "Cuerpo", texStage2, new Vector3(0f, s2Y, 0f), s2H, 5);
        else
            MakePart(stage2, "Cuerpo", squareSprite, new Color(0.78f, 0.8f, 0.9f), new Vector3(0f, s2Y, 0f), new Vector3(0.7f * rocketScale, s2H, 1f), 5);

        if (texFairing != null)
        {
            var fairingGo = MakeTexturedPart(stage2, "Cofia", texFairing, new Vector3(0f, s2Y + s2H * 0.72f, 0f), s2H * 0.85f, 6);
            fairingPart = fairingGo.transform;
        }

        if (texFlame2 != null)
            flame2 = MakeTexturedPart(stage2, "Llama", texFlame2, new Vector3(0f, flame2BaseY - flame2Height / 2f, 0f), flame2Height, 4);
        else
            flame2 = MakePart(stage2, "Llama", squareSprite, new Color(1f, 0.6f, 0.15f), new Vector3(0f, flame2BaseY - flame2Height / 2f, 0f), new Vector3(flame2Width, flame2Height, 1f), 4);
        flame2.enabled = false;
    }

    // Llama: con tu textura (si hay) o un rectángulo naranja
    SpriteRenderer MakeFlame(Transform parent, Vector3 localPos, float width, float height, Color fallback)
    {
        if (vis.rocketFlame != null)
            return MakeTexturedPart(parent, "Llama", vis.rocketFlame, localPos, height, 4);
        return MakePart(parent, "Llama", squareSprite, fallback, localPos, new Vector3(width, height, 1f), 4);
    }

    // Parte con textura: se escala parejo para que mida "height" de alto y conserve su proporción
    static SpriteRenderer MakeTexturedPart(Transform parent, string partName, Texture2D tex, Vector3 localPos, float height, int order)
    {
        var go = new GameObject(partName);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = new Vector3(height, height, 1f);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = GameVisuals.MakeSprite(tex);
        sr.sortingOrder = order;
        return sr;
    }

    static SpriteRenderer MakePart(Transform parent, string partName, Sprite sprite, Color color, Vector3 localPos, Vector3 scale, int order)
    {
        var go = new GameObject(partName);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = scale;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        return sr;
    }

    static Sprite MakeCircleSprite()
    {
        int size = 128;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        float r = size / 2f;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(r, r));
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(r - d)));
            }
        }
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
    }

    static Sprite MakeSquareSprite()
    {
        var tex = new Texture2D(4, 4, TextureFormat.RGBA32, false);
        for (int y = 0; y < 4; y++)
            for (int x = 0; x < 4; x++)
                tex.SetPixel(x, y, Color.white);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f), 4);
    }
}
