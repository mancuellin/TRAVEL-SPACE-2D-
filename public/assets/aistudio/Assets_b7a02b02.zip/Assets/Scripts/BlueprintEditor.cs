using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

// Editor de diseño + mapa orbital + lanzamiento + operación y debriefing.
// Se pone en un GameObject de la escena.
public class BlueprintEditor : MonoBehaviour
{
    const float OperationDaysPerSecond = 8f;

    [Header("Se llenan solos con el menú ⋮ > Cargar todo desde Assets")]
    public MissionBriefing briefing;
    public List<MissionBriefing> briefings = new List<MissionBriefing>();
    public List<PartData> availableParts = new List<PartData>();
    public List<LauncherData> launchers = new List<LauncherData>();
    public List<OrbitData> orbits = new List<OrbitData>();

    // El diseño actual del jugador (se pueden repetir piezas)
    readonly List<PartData> design = new List<PartData>();
    int launcherIndex;
    int orbitIndex;
    MissionResult result;
    OrbitMapView map;
    LaunchView launch;
    MissionOperation op;
    float opAccum;

    // 0 = Blueprint, 1 = Mapa orbital, 2 = Lanzamiento, 3 = Operación
    int tab;

    int speedIndex;
    readonly string[] speedLabels = { "x1", "x5", "x20" };
    readonly float[] speedMultipliers = { 1f, 5f, 20f };

    int opSpeedIndex;
    readonly string[] opSpeedLabels = { "x1", "x3", "x10" };
    readonly float[] opSpeedMultipliers = { 1f, 3f, 10f };

    string[] launcherNames = new string[0];
    string[] orbitNames = new string[0];
    string[] briefingTitles = new string[0];
    int briefingIndex;
    Vector2 scrollParts;
    Vector2 scrollReport;
    Vector2 scrollOp;
    GUIStyle label, button, header, goodStyle, badStyle, goodLine, badLine;
    GUIStyle titleStyle, subtitleStyle, accentStyle, quoteStyle, bigButton, tooltipStyle, tabActive;

    // Personalización visual (colores, fuente, texturas de la interfaz)
    GameVisuals vis;
    bool rebuildStyles;
    readonly string[] themeNames = { "Azul", "Naranja", "Verde", "Violeta" };

    // Menú principal
    bool inMenu = true;
    StoryIntro story;
    StoryEnding ending;
    bool showHelp;
    readonly Dictionary<PartData, string> tipCache = new Dictionary<PartData, string>();

    void Start()
    {
        vis = GetComponent<GameVisuals>();
        if (vis == null) vis = gameObject.AddComponent<GameVisuals>(); // sin texturas: usa reemplazos

        map = GetComponent<OrbitMapView>();
        if (map == null) map = gameObject.AddComponent<OrbitMapView>();
        launch = GetComponent<LaunchView>();
        if (launch == null) launch = gameObject.AddComponent<LaunchView>();
        story = GetComponent<StoryIntro>();
        if (story == null) story = gameObject.AddComponent<StoryIntro>(); // sin imágenes: usa reemplazos
        story.OnFinished = OnStoryFinished;
        ending = GetComponent<StoryEnding>();
        if (ending == null) ending = gameObject.AddComponent<StoryEnding>(); // sin imagen: usa reemplazo
        ending.OnFinished = OnEndingFinished;

        // Quitar referencias vacías (por ejemplo, de assets que se borraron)
        availableParts.RemoveAll(x => x == null);
        launchers.RemoveAll(x => x == null);
        orbits.RemoveAll(x => x == null);
        briefings.RemoveAll(x => x == null);

        EnsureDefaultMissions();
        if (briefings.Count > 0 && !briefings.Contains(briefing))
            briefing = briefings[Mathf.Min(1, briefings.Count - 1)];
        briefingIndex = Mathf.Max(0, briefings.IndexOf(briefing));

        RefreshNames();
        Recalculate();
    }

    void Update()
    {
        if (launch != null) launch.ViewActive = (!inMenu && tab == 2);

        // Avanzar la operación (se simula un día por paso)
        if (op != null && !op.Finished)
        {
            opAccum += Time.deltaTime * OperationDaysPerSecond * opSpeedMultipliers[opSpeedIndex];
            while (opAccum >= 1f && !op.Finished)
            {
                op.StepDay();
                opAccum -= 1f;
            }
        }
        if (op != null && map != null && result != null)
        {
            map.UpdatePower(result.solarWatts * op.SolarHealth, result.rtgWatts, result.consumptionWatts);
            map.SetOffline(op.Finished && !op.Succeeded);
        }
    }

    // Misiones integradas: se crean en memoria si no existen como assets en la carpeta Data.
    void EnsureDefaultMissions()
    {
        if (!HasMission(20f))
            briefings.Add(MakeMission("Fácil: primera misión",
                "Tutorial: observa la Tierra con una cámara. Presupuesto holgado y misión corta.", 60f, 20f, 90f));
        if (!HasMission(40f))
            briefings.Add(MakeMission("Estándar: observación con cámara HD",
                "Observa la Tierra con cámara HD sin pasarte del presupuesto.", 40f, 40f, 180f));
        if (!HasMission(100f))
            briefings.Add(MakeMission("Difícil: observatorio de alta resolución",
                "Necesitas cámara y radar, un año de vida útil y poco margen de presupuesto.", 50f, 100f, 365f));

        briefings.Sort((a, b) => a.minSciencePoints.CompareTo(b.minSciencePoints));
    }

    bool HasMission(float minScience)
    {
        foreach (var b in briefings)
            if (b != null && Mathf.Approximately(b.minSciencePoints, minScience)) return true;
        return false;
    }

    static MissionBriefing MakeMission(string title, string description, float budget, float minScience, float days)
    {
        var b = ScriptableObject.CreateInstance<MissionBriefing>();
        b.title = title;
        b.description = description;
        b.budgetMillions = budget;
        b.minSciencePoints = minScience;
        b.missionDays = days;
        return b;
    }

    void RefreshNames()
    {
        launcherNames = new string[launchers.Count];
        for (int i = 0; i < launchers.Count; i++)
            launcherNames[i] = launchers[i].launcherName + "\n" + launchers[i].capacityKg.ToString("F0") + " kg | $" + launchers[i].costMillions.ToString("F0") + "M";

        briefingTitles = new string[briefings.Count];
        for (int i = 0; i < briefings.Count; i++)
            briefingTitles[i] = (briefings[i] != null) ? briefings[i].title : "?";

        orbitNames = new string[orbits.Count];
        for (int i = 0; i < orbits.Count; i++)
            orbitNames[i] = orbits[i].orbitName + "\n" + orbits[i].altitudeKm.ToString("F0") + " km | ΔV " + orbits[i].deltaVRequired.ToString("F0");
    }

    LauncherData CurrentLauncher()
    {
        return (launchers.Count > 0) ? launchers[Mathf.Clamp(launcherIndex, 0, launchers.Count - 1)] : null;
    }

    OrbitData CurrentOrbit()
    {
        return (orbits.Count > 0) ? orbits[Mathf.Clamp(orbitIndex, 0, orbits.Count - 1)] : null;
    }

    void Recalculate()
    {
        result = MissionCalculator.Calculate(design, CurrentLauncher(), CurrentOrbit(), briefing);

        // Si cambia el diseño o la órbita, hay que volver a lanzar y a operar
        op = null;
        if (map != null)
        {
            map.SetOrbit(CurrentOrbit());
            map.SetPower(result.solarWatts, result.rtgWatts, result.consumptionWatts, result.batteryWh);
            map.SetOffline(false);
        }
        if (launch != null) launch.Prepare(result.launcherCapacityKg);
    }

    void StartOperation()
    {
        op = new MissionOperation(design, result, CurrentOrbit(), briefing, System.Environment.TickCount);
        opAccum = 0f;
        scrollOp = Vector2.zero;
        if (map != null)
        {
            map.SetOrbit(CurrentOrbit());
            map.SetPower(result.solarWatts, result.rtgWatts, result.consumptionWatts, result.batteryWh);
            map.SetOffline(op.Finished && !op.Succeeded);
        }
    }

    int CountOf(PartData p)
    {
        int n = 0;
        foreach (var d in design) if (d == p) n++;
        return n;
    }

    int FS(int size)
    {
        return Mathf.Max(8, Mathf.RoundToInt(size * vis.fontScale));
    }

    static void SetTextColor(GUIStyle st, Color c)
    {
        st.normal.textColor = c;
        st.hover.textColor = c;
        st.active.textColor = c;
        st.focused.textColor = c;
        st.onNormal.textColor = c;
        st.onHover.textColor = c;
        st.onActive.textColor = c;
        st.onFocused.textColor = c;
    }

    void InitStyles()
    {
        if (rebuildStyles)
        {
            label = null; // el tema cambió: se vuelven a crear los estilos
            rebuildStyles = false;
        }
        if (label != null) return;

        Color text = vis.TextColor;
        Color accent = vis.Accent;
        Color highlight = vis.Highlight;

        label = new GUIStyle(GUI.skin.label) { fontSize = FS(16), wordWrap = true };
        label.normal.textColor = text;

        header = new GUIStyle(GUI.skin.label) { fontSize = FS(22), fontStyle = FontStyle.Bold, wordWrap = true };
        header.normal.textColor = accent;

        // Botones: con tus texturas (si las pusiste) o planos del color del tema
        button = new GUIStyle(GUI.skin.button) { fontSize = FS(18) };
        Texture2D bn = vis.ButtonTexture(0);
        Texture2D bh = vis.ButtonTexture(1);
        Texture2D bp = vis.ButtonTexture(2);
        int b = (vis.buttonNormal != null) ? Mathf.Max(1, vis.buttonBorder) : 2;
        button.normal.background = bn;
        button.hover.background = bh;
        button.active.background = bp;
        button.focused.background = bh;
        button.onNormal.background = bp;   // botón "seleccionado"
        button.onHover.background = bp;
        button.onActive.background = bp;
        button.onFocused.background = bp;
        button.border = new RectOffset(b, b, b, b);
        button.padding = new RectOffset(8, 8, 4, 4);
        SetTextColor(button, text);

        // Pestaña activa
        tabActive = new GUIStyle(button) { fontStyle = FontStyle.Bold };
        tabActive.normal.background = bp;
        tabActive.hover.background = bp;
        tabActive.focused.background = bp;
        SetTextColor(tabActive, accent);

        goodStyle = new GUIStyle(label) { fontSize = FS(18), fontStyle = FontStyle.Bold };
        goodStyle.normal.textColor = new Color(0.3f, 1f, 0.45f);
        badStyle = new GUIStyle(label) { fontSize = FS(18), fontStyle = FontStyle.Bold };
        badStyle.normal.textColor = new Color(1f, 0.4f, 0.35f);
        goodLine = new GUIStyle(label);
        goodLine.normal.textColor = new Color(0.45f, 1f, 0.55f);
        badLine = new GUIStyle(label);
        badLine.normal.textColor = new Color(1f, 0.5f, 0.45f);

        titleStyle = new GUIStyle(label) { fontSize = FS(40), fontStyle = FontStyle.Bold };
        titleStyle.normal.textColor = highlight;
        subtitleStyle = new GUIStyle(label) { fontSize = FS(17) };
        subtitleStyle.normal.textColor = Color.Lerp(text, Color.gray, 0.4f);
        accentStyle = new GUIStyle(label) { fontSize = FS(14) };
        accentStyle.normal.textColor = accent;
        quoteStyle = new GUIStyle(label) { fontSize = FS(15), fontStyle = FontStyle.Italic };
        quoteStyle.normal.textColor = Color.Lerp(text, Color.gray, 0.5f);
        bigButton = new GUIStyle(button) { fontSize = FS(24), fontStyle = FontStyle.Bold };
        tooltipStyle = new GUIStyle(label) { fontSize = FS(15) };

        // Tipografía propia (si la pusiste)
        if (vis.uiFont != null)
        {
            GUIStyle[] all = { label, header, button, tabActive, goodStyle, badStyle, goodLine, badLine,
                               titleStyle, subtitleStyle, accentStyle, quoteStyle, bigButton, tooltipStyle };
            foreach (var st in all) st.font = vis.uiFont;
        }
    }

    static void Fill(Rect r, Color c)
    {
        GUI.color = c;
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = Color.white;
    }

    // Fondo de los paneles: tu imagen o el color del tema
    void DrawPanelBackground(Rect r)
    {
        if (vis.panelTexture != null) GUI.DrawTexture(r, vis.panelTexture, ScaleMode.StretchToFill, true);
        else Fill(r, vis.PanelColor);
    }

    void CycleTheme()
    {
        int next = ((int)vis.theme + 1) % 4;
        vis.SetTheme((UiTheme)next);
        rebuildStyles = true;
    }

    void OnGUI()
    {
        InitStyles();
        float w = Screen.width;
        float h = Screen.height;
        if (ending != null && ending.IsPlaying)
        {
            ending.Draw(w, h);
            return;
        }

        if (story != null && story.IsPlaying)
        {
            story.Draw(w, h);
            return;
        }

        if (inMenu)
        {
            DrawMainMenu(w, h);
            return;
        }

        int drawTab = tab; // se fija al inicio para que no cambie a mitad del dibujado

        if (drawTab == 0)
        {
            // Fondo que tapa todo (tu imagen o un color liso)
            if (vis.uiBackground != null)
            {
                GUI.DrawTexture(new Rect(0, 0, w, h), vis.uiBackground, ScaleMode.ScaleAndCrop, true);
                Fill(new Rect(0, 0, w, h), new Color(0f, 0f, 0f, 0.45f)); // para que el texto se lea bien
            }
            else
            {
                Fill(new Rect(0, 0, w, h), vis.BackgroundColor);
            }
        }
        else
        {
            // Solo un panel a la izquierda (el resto deja ver el mapa o el cohete)
            float panelFrac = (drawTab == 1) ? 0.25f : (drawTab == 2 ? 0.28f : 0.40f);
            DrawPanelBackground(new Rect(0, 0, w * panelFrac, h));
        }
        GUI.color = Color.white;

        // Pestañas
        Color normal = GUI.backgroundColor;
        TabButton(new Rect(10, 10, 165, 40), "BLUEPRINT", 0, drawTab, normal);
        TabButton(new Rect(185, 10, 165, 40), "MAPA ORBITAL", 1, drawTab, normal);
        TabButton(new Rect(360, 10, 165, 40), "LANZAMIENTO", 2, drawTab, normal);
        TabButton(new Rect(535, 10, 165, 40), "OPERACIÓN", 3, drawTab, normal);
        GUI.backgroundColor = normal;
        if (GUI.Button(new Rect(w - 250, 10, 110, 40), "ESTILO", button))
            CycleTheme();
        if (GUI.Button(new Rect(w - 130, 10, 120, 40), "MENÚ", button))
        {
            inMenu = true;
            showHelp = false;
        }

        if (drawTab == 0) DrawBlueprint(w, h);
        else if (drawTab == 1) DrawMapPanel(w, h);
        else if (drawTab == 2) DrawLaunchPanel(w, h);
        else DrawOperationPanel(w, h);

        DrawTooltip(w, h);
    }

    void TabButton(Rect r, string text, int index, int drawTab, Color normal)
    {
        if (GUI.Button(r, text, (drawTab == index) ? tabActive : button)) tab = index;
    }

    void DrawBar(float frac, Color fill)
    {
        Rect bar = GUILayoutUtility.GetRect(10, 26, GUILayout.ExpandWidth(true));
        if (Event.current.type != EventType.Repaint) return;

        GUI.color = new Color(0.15f, 0.17f, 0.25f, 1f);
        GUI.DrawTexture(bar, Texture2D.whiteTexture);
        GUI.color = fill;
        GUI.DrawTexture(new Rect(bar.x, bar.y, bar.width * Mathf.Clamp01(frac), bar.height), Texture2D.whiteTexture);
        GUI.color = Color.white;
    }

    // ---------- Menú principal ----------

    void DrawMainMenu(float w, float h)
    {
        float pw = Mathf.Min(w, Mathf.Max(w * 0.42f, 520f));

        // Panel izquierdo sobre el mapa orbital animado (que se ve a la derecha)
        if (Event.current.type == EventType.Repaint)
        {
            DrawPanelBackground(new Rect(0, 0, pw, h));

            // Rejilla de plano técnico
            GUI.color = new Color(vis.Highlight.r, vis.Highlight.g, vis.Highlight.b, 0.07f);
            for (float x = 0f; x < pw; x += 40f) GUI.DrawTexture(new Rect(x, 0, 1, h), Texture2D.whiteTexture);
            for (float y = 0f; y < h; y += 40f) GUI.DrawTexture(new Rect(0, y, pw, 1), Texture2D.whiteTexture);

            // Barra de acento
            GUI.color = vis.Highlight;
            GUI.DrawTexture(new Rect(0, 0, 6, h), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        GUILayout.BeginArea(new Rect(48, h * 0.08f, pw - 96, h * 0.86f));

        GUILayout.Label("THE TRAVEL SPACE 2D", titleStyle);
        GUILayout.Label("Simulador interactivo de diseño y gestión de misiones espaciales", subtitleStyle);
        GUILayout.Space(12);
        GUILayout.Label("ESTILO: 2D plano técnico / HUD    ENFOQUE: ingeniería y trade-offs\n" +
                        "PERSPECTIVA: vista lateral y mapa 2D    AUDIENCIA: estudiantes / STEM", accentStyle);
        GUILayout.Space(26);

        if (!showHelp)
        {
            if (GUILayout.Button("NUEVO JUEGO", bigButton, GUILayout.Height(70)))
            {
                showHelp = false;
                story.Play(); // al terminar la historia se abre el simulador
            }
            GUILayout.Space(10);
            if (GUILayout.Button("IR DIRECTO AL SIMULADOR", button, GUILayout.Height(52)))
            {
                inMenu = false;
                tab = 0;
            }
            GUILayout.Space(10);
            if (GUILayout.Button("VER EL FINAL (PRUEBA)", button, GUILayout.Height(40)))
                ending.Play("Estándar: observación con cámara HD", "LEO", 180, 50f, 82f, "Buen diseño");
            GUILayout.Space(10);
            if (GUILayout.Button("CÓMO JUGAR", button, GUILayout.Height(52)))
                showHelp = true;
            GUILayout.Space(10);
            if (GUILayout.Button("SALIR", button, GUILayout.Height(52)))
                QuitGame();
        }
        else
        {
            GUILayout.Label("CÓMO JUGAR", header);
            GUILayout.Label(
                "1. MISIÓN: elige Fácil, Estándar o Difícil. Cada una define presupuesto, ciencia mínima y vida útil.\n\n" +
                "2. BLUEPRINT: arma tu satélite con los botones + y -. Pasa el cursor sobre una pieza para ver qué hace. " +
                "Elige también el lanzador y la órbita.\n\n" +
                "3. LANZAMIENTO: si la masa supera al cohete, falla. Si el ΔV no alcanza, no llegas a la órbita.\n\n" +
                "4. OPERACIÓN: tormentas de radiación, paneles que se degradan y fallos de antena ponen a prueba tu diseño.\n\n" +
                "5. DEBRIEFING: recibes una puntuación y la causa exacta de cualquier falla.", label);
            GUILayout.Space(10);
            if (GUILayout.Button("VOLVER", button, GUILayout.Height(48)))
                showHelp = false;
        }

        GUILayout.FlexibleSpace();
        GUILayout.Label("\"En el espacio no existe el diseño perfecto, solo el equilibrio sostenible.\"", quoteStyle);
        GUILayout.EndArea();

        // Botones para cambiar el estilo de toda la interfaz del simulador
        GUI.Label(new Rect(w - 520f, 8f, 500f, 24f), "ESTILO DE LA INTERFAZ DEL SIMULADOR", accentStyle);
        int current = (vis.theme == UiTheme.Personalizado) ? -1 : (int)vis.theme;
        int chosen = GUI.Toolbar(new Rect(w - 520f, 34f, 500f, 38f), current, themeNames, button);
        if (chosen != current && chosen >= 0)
        {
            vis.SetTheme((UiTheme)chosen);
            rebuildStyles = true;
        }
    }

    // Muestra el final con los datos reales de la partida
    void PlayEnding(MissionOperation o)
    {
        OrbitData orb = CurrentOrbit();
        ending.Play(briefing != null ? briefing.title : "", orb != null ? orb.orbitName : "",
                    o.TotalDays, o.ScienceDelivered, o.Score, o.Rating);
    }

    void OnEndingFinished(bool toMenu)
    {
        if (toMenu)
        {
            inMenu = true;
            showHelp = false;
        }
        else
        {
            inMenu = false;
            tab = 3;
        }
    }

    // Cuando termina (o se salta) la historia, se abre el simulador
    void OnStoryFinished()
    {
        inMenu = false;
        showHelp = false;
        tab = 0;
    }

    void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ---------- Descripciones al pasar el cursor ----------

    string GetTip(PartData p)
    {
        string tip;
        if (!tipCache.TryGetValue(p, out tip))
        {
            tip = PartTooltip(p);
            tipCache[p] = tip;
        }
        return tip;
    }

    static string N0(float v) { return v.ToString("F0"); }

    static string PartTooltip(PartData p)
    {
        string text = p.partName.ToUpper() + "\n" + TypeDescription(p) + "\n\n";
        text += "Masa: " + N0(p.massKg) + " kg   Costo: $" + p.costMillions.ToString("F1") + "M";
        if (p.powerWatts > 0f) text += "\nGenera: " + N0(p.powerWatts) + " W";
        else if (p.powerWatts < 0f) text += "\nConsume: " + N0(-p.powerWatts) + " W";
        if (p.batteryWh > 0f) text += "\nBatería: " + N0(p.batteryWh) + " Wh";
        if (p.fuelKg > 0f) text += "\nCombustible: " + N0(p.fuelKg) + " kg";
        if (p.sciencePoints > 0f) text += "\nCiencia: " + N0(p.sciencePoints) + " puntos";
        return text;
    }

    static string TypeDescription(PartData p)
    {
        switch (p.type)
        {
            case PartType.Structure:
                return "Es el chasis del satélite: sostiene todo lo demás. Aporta masa y costo, pero no energía ni ciencia.";
            case PartType.SolarPanel:
                return "Convierte la luz del Sol en electricidad. Solo genera en la parte iluminada de la órbita (nada durante el eclipse) y se degrada con la radiación a lo largo de los días.";
            case PartType.RTG:
                return "Generador de radioisótopos: produce energía constante, incluso en eclipse. Es caro y pesado, pero no depende del Sol ni se degrada como los paneles.";
            case PartType.Battery:
                return "Guarda energía para sobrevivir al eclipse, cuando los paneles no generan nada. Se recarga durante la parte iluminada de la órbita.";
            case PartType.Antenna:
                float rate = (p.dataRate > 0f) ? p.dataRate : 0.5f;
                return "Envía los datos científicos a la Tierra. Esta antena transmite el " + N0(rate * 100f) + "% de la ciencia" +
                       (rate < 1f ? ": gasta poco, pero pierdes datos." : ": entrega todo, pero gasta más energía.") +
                       " Con una sola antena, si falla el enlace cae 10 días; con dos, la de respaldo lo cubre.";
            case PartType.Computer:
                return "Es el cerebro de la nave: sin computadora no hay misión. Aguanta " + Mathf.Max(1, p.computerLives) +
                       " tormenta(s) de radiación severa(s); después queda fuera de servicio. El blindaje ayuda a protegerla.";
            case PartType.Instrument:
                return "Es el motivo de la misión: genera ciencia. Consume energía, y los datos solo cuentan si una antena los transmite a la Tierra.";
            case PartType.Fuel:
                return "Combustible para cambiar de órbita: da ΔV (capacidad de maniobra). Las órbitas altas necesitan más ΔV, pero el combustible suma masa y el cohete debe poder levantarla.";
            case PartType.Shielding:
                return "Reduce un " + N0(p.shielding * 100f) + "% la intensidad de las tormentas de radiación que amenazan a la computadora. Los blindajes se suman (máximo 80%), pero agregan masa.";
            default:
                return "";
        }
    }

    void DrawTooltip(float w, float h)
    {
        string tip = GUI.tooltip;
        if (string.IsNullOrEmpty(tip) || Event.current.type != EventType.Repaint) return;

        float tw = Mathf.Min(400f, w - 20f);
        float th = tooltipStyle.CalcHeight(new GUIContent(tip), tw - 24f) + 20f;
        Vector2 m = Event.current.mousePosition;
        float x = Mathf.Clamp(m.x + 18f, 10f, Mathf.Max(10f, w - tw - 10f));
        float y = Mathf.Clamp(m.y + 18f, 10f, Mathf.Max(10f, h - th - 10f));

        GUI.color = vis.Highlight;
        GUI.DrawTexture(new Rect(x - 2f, y - 2f, tw + 4f, th + 4f), Texture2D.whiteTexture);
        Color tipBg = Color.Lerp(vis.BackgroundColor, Color.black, 0.25f);
        tipBg.a = 1f;
        GUI.color = tipBg;
        GUI.DrawTexture(new Rect(x, y, tw, th), Texture2D.whiteTexture);
        GUI.color = Color.white;
        GUI.Label(new Rect(x + 12f, y + 10f, tw - 24f, th - 20f), tip, tooltipStyle);
    }

    // ---------- Pestaña 1: Blueprint ----------

    void DrawBlueprint(float w, float h)
    {
        bool changed = false;
        float top = 60f;

        float x1 = 10f, w1 = w * 0.32f;
        float x2 = x1 + w1 + 10f, w2 = w * 0.20f;
        float x3 = x2 + w2 + 10f, w3 = w - x3 - 10f;

        // Columna 1: piezas
        GUILayout.BeginArea(new Rect(x1, top, w1, h - top - 10));
        GUILayout.Label("PIEZAS", header);
        scrollParts = GUILayout.BeginScrollView(scrollParts);
        foreach (var p in availableParts)
        {
            if (p == null) continue;
            GUILayout.BeginHorizontal();
            string tip = GetTip(p);
            GUILayout.Label(new GUIContent(p.partName + "\n" + p.massKg.ToString("F0") + " kg | $" + p.costMillions.ToString("F1") + "M", tip), label);
            if (GUILayout.Button(new GUIContent("-", tip), button, GUILayout.Width(44), GUILayout.Height(44)))
            {
                design.Remove(p);
                changed = true;
            }
            GUILayout.Label(CountOf(p).ToString(), label, GUILayout.Width(30));
            if (GUILayout.Button(new GUIContent("+", tip), button, GUILayout.Width(44), GUILayout.Height(44)))
            {
                design.Add(p);
                changed = true;
            }
            GUILayout.EndHorizontal();
        }
        GUILayout.EndScrollView();
        if (GUILayout.Button("Vaciar diseño", button, GUILayout.Height(36)))
        {
            design.Clear();
            changed = true;
        }
        GUILayout.EndArea();

        // Columna 2: lanzador y órbita
        GUILayout.BeginArea(new Rect(x2, top, w2, h - top - 10));
        GUILayout.Label("LANZADOR", header);
        if (launcherNames.Length > 0)
        {
            int n = GUILayout.SelectionGrid(launcherIndex, launcherNames, 1, button);
            if (n != launcherIndex) { launcherIndex = n; changed = true; }
        }
        GUILayout.Space(20);
        GUILayout.Label("ÓRBITA", header);
        if (orbitNames.Length > 0)
        {
            int n = GUILayout.SelectionGrid(orbitIndex, orbitNames, 1, button);
            if (n != orbitIndex) { orbitIndex = n; changed = true; }
        }
        GUILayout.EndArea();

        if (changed) Recalculate();

        // Columna 3: misión y resultados
        GUILayout.BeginArea(new Rect(x3, top, w3, h - top - 10));
        if (briefingTitles.Length > 1)
        {
            GUILayout.Label("MISIÓN", header);
            int nb = GUILayout.SelectionGrid(briefingIndex, briefingTitles, 1, button);
            if (nb != briefingIndex)
            {
                briefingIndex = nb;
                briefing = briefings[nb];
                Recalculate();
            }
            GUILayout.Space(8);
        }
        if (briefing != null)
        {
            GUILayout.Label(briefing.title, header);
            GUILayout.Label(briefing.description, label);
            GUILayout.Label("Presupuesto: $" + briefing.budgetMillions.ToString("F0") + "M | Ciencia mínima: " +
                            briefing.minSciencePoints.ToString("F0") + " | Vida útil: " + briefing.missionDays.ToString("F0") + " días", label);
            GUILayout.Space(10);
        }
        scrollReport = GUILayout.BeginScrollView(scrollReport);
        if (result != null) GUILayout.Label(result.ToReport(), label);
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    // ---------- Pestaña 2: Mapa orbital ----------

    void DrawMapPanel(float w, float h)
    {
        if (map == null) return;
        float panelW = w * 0.25f;

        GUILayout.BeginArea(new Rect(10, 60, panelW - 20, h - 70));

        GUILayout.Label("ÓRBITA", header);
        if (orbitNames.Length > 0)
        {
            int n = GUILayout.SelectionGrid(orbitIndex, orbitNames, 1, button);
            if (n != orbitIndex) { orbitIndex = n; Recalculate(); }
        }

        GUILayout.Space(8);
        GUILayout.Label("VELOCIDAD", header);
        speedIndex = GUILayout.Toolbar(speedIndex, speedLabels, button, GUILayout.Height(34));
        map.speedMultiplier = speedMultipliers[speedIndex];

        GUILayout.Space(8);
        float pct = (map.PeriodMinutes > 0f) ? map.EclipseMinutes / map.PeriodMinutes * 100f : 0f;
        GUILayout.Label("Periodo: " + map.PeriodMinutes.ToString("F0") + " min\n" +
                        "Eclipse: " + map.EclipseMinutes.ToString("F0") + " min (" + pct.ToString("F0") + "% de la órbita)\n" +
                        "Tiempo simulado: " + map.SimTimeMinutes.ToString("F0") + " min", label);

        GUILayout.Space(6);
        GUILayout.Label(map.InEclipse ? "Estado: EN ECLIPSE" : "Estado: EN LUZ SOLAR", label);
        GUILayout.Label("Generación: " + map.GenerationW.ToString("F0") + " W   Consumo: " + map.ConsumptionW.ToString("F0") + " W", label);

        GUILayout.Label("Batería: " + map.BatteryWh.ToString("F0") + " / " + map.BatteryCapacityWh.ToString("F0") + " Wh", label);
        float frac = (map.BatteryCapacityWh > 0f) ? map.BatteryWh / map.BatteryCapacityWh : 0f;
        Color fill = map.PowerFailure ? new Color(0.9f, 0.2f, 0.2f)
                   : (frac < 0.3f ? new Color(1f, 0.6f, 0.1f) : new Color(0.3f, 0.9f, 0.4f));
        DrawBar(frac, fill);

        GUILayout.Space(6);
        GUILayout.Label(map.PowerFailure
            ? "¡SIN ENERGÍA! La nave dejó de operar. Vuelve al Blueprint y revisa paneles o baterías."
            : " ", label);

        GUILayout.EndArea();
    }

    // ---------- Pestaña 3: Lanzamiento ----------

    void DrawLaunchPanel(float w, float h)
    {
        if (launch == null || result == null) return;

        LaunchOutcome outcome = launch.Outcome; // se fija para que no cambie a mitad del dibujado
        float panelW = w * 0.28f;

        GUILayout.BeginArea(new Rect(10, 60, panelW - 20, h - 70));
        GUILayout.Label("LANZAMIENTO", header);

        LauncherData l = CurrentLauncher();
        OrbitData o = CurrentOrbit();
        string launcherName = (l != null) ? l.launcherName : "-";
        string orbitName = (o != null) ? o.orbitName : "-";

        GUILayout.Label("Lanzador: " + launcherName + "\n" +
                        "Órbita objetivo: " + orbitName + "\n" +
                        "Masa: " + result.totalMassKg.ToString("F0") + " / " + result.launcherCapacityKg.ToString("F0") + " kg\n" +
                        "ΔV: " + result.deltaVAvailable.ToString("F0") + " / " + result.deltaVRequired.ToString("F0") + " m/s\n" +
                        "Costo: $" + result.totalCost.ToString("F1") + "M / $" + result.budget.ToString("F1") + "M", label);
        GUILayout.Space(10);

        bool hasDesign = result.totalMassKg > 0f;
        bool budgetOk = result.totalCost <= result.budget;

        if (outcome == LaunchOutcome.Idle)
        {
            if (!hasDesign)
            {
                GUILayout.Label("Arma un diseño en el Blueprint antes de lanzar.", label);
            }
            else if (!budgetOk)
            {
                GUILayout.Label("MISIÓN NO AUTORIZADA: presupuesto excedido ($" + result.totalCost.ToString("F1") +
                                "M de $" + result.budget.ToString("F1") + "M). Reduce costos en el Blueprint.", badStyle);
            }
            else
            {
                if (GUILayout.Button("LANZAR", button, GUILayout.Height(60)))
                    launch.StartLaunch(result, orbitName);
                GUILayout.Label("La misión está autorizada. Si la masa o el ΔV no alcanzan, lo verás en vivo.", label);
            }
        }
        else if (outcome == LaunchOutcome.Running)
        {
            GUILayout.Label(launch.Phase, header);
            GUILayout.Label("Altitud: " + launch.AltitudeKm.ToString("F0") + " km\n" +
                            "Velocidad: " + launch.SpeedKms.ToString("F1") + " km/s", label);
            GUILayout.Space(6);
            GUILayout.Label("ΔV de circularización: " + launch.DeltaVBurned.ToString("F0") + " / " + launch.DeltaVRequired.ToString("F0") + " m/s", label);
            float f = (launch.DeltaVRequired > 0f) ? launch.DeltaVBurned / launch.DeltaVRequired : 0f;
            DrawBar(f, new Color(0.3f, 0.75f, 1f));
        }
        else
        {
            bool ok = (outcome == LaunchOutcome.Success);
            GUILayout.Label(launch.Phase, ok ? goodStyle : badStyle);
            GUILayout.Label(launch.ResultMessage, label);
            GUILayout.Space(10);
            if (ok)
            {
                GUILayout.Label("La nave llegó a órbita. Ahora ve a la pestaña OPERACIÓN para ver si sobrevive toda su vida útil.", label);
                GUILayout.Space(6);
            }
            if (GUILayout.Button("Volver a la plataforma", button, GUILayout.Height(44)))
                launch.Prepare(result.launcherCapacityKg);
        }

        GUILayout.EndArea();
    }

    // ---------- Pestaña 4: Operación y debriefing ----------

    void DrawOperationPanel(float w, float h)
    {
        if (map == null || result == null) return;

        MissionOperation o = op; // se fija para que no cambie a mitad del dibujado
        bool launched = launch != null && launch.Outcome == LaunchOutcome.Success;
        float panelW = w * 0.40f;

        GUILayout.BeginArea(new Rect(10, 60, panelW - 20, h - 70));
        scrollOp = GUILayout.BeginScrollView(scrollOp);
        GUILayout.Label("OPERACIÓN Y DEBRIEFING", header);

        if (o == null)
        {
            if (!launched)
            {
                GUILayout.Label("Primero necesitas un lanzamiento exitoso. Ve a la pestaña LANZAMIENTO y lanza tu diseño.", label);
            }
            else
            {
                GUILayout.Label("La nave está en órbita. Ahora debe sobrevivir toda su vida útil con eventos al azar: " +
                                "degradación de los paneles, tormentas de radiación y fallos de antena.", label);
                GUILayout.Space(8);
                if (GUILayout.Button("INICIAR OPERACIÓN", button, GUILayout.Height(60)))
                    StartOperation();
            }
        }
        else
        {
            // Indicadores en vivo
            GUILayout.Label("Día " + o.Day + " / " + o.TotalDays, label);
            DrawBar((float)o.Day / Mathf.Max(1, o.TotalDays), new Color(0.3f, 0.75f, 1f));
            if (!o.Finished)
                opSpeedIndex = GUILayout.Toolbar(opSpeedIndex, opSpeedLabels, button, GUILayout.Height(30));

            GUILayout.Space(6);
            GUILayout.Label("Paneles solares: " + (o.SolarHealth * 100f).ToString("F0") + "% de su capacidad", label);
            GUILayout.Label("Computadora: " + (o.ComputerAlive ? "operativa (vidas restantes: " + o.ComputerLivesLeft + ")" : "FUERA DE SERVICIO"), label);
            GUILayout.Label("Enlace de datos: " + (o.LinkUp ? "activo" : "CAÍDO (" + o.LinkDownDaysLeft + " días)"), label);
            GUILayout.Label("Ciencia entregada: " + o.ScienceDelivered.ToString("F0") + " / " + o.MinScience.ToString("F0") + " requeridos", label);
            DrawBar(o.MinScience > 0f ? o.ScienceDelivered / o.MinScience : 0f, new Color(0.3f, 0.9f, 0.4f));

            // Bitácora (durante la misión solo las últimas líneas; al final, toda)
            GUILayout.Space(8);
            GUILayout.Label("BITÁCORA", header);
            int count = o.Log.Count;
            int start = o.Finished ? 0 : Mathf.Max(0, count - 8);
            for (int i = start; i < count; i++)
            {
                OperationEvent e = o.Log[i];
                GUIStyle st = (e.kind == LogKind.Bad) ? badLine : ((e.kind == LogKind.Good) ? goodLine : label);
                GUILayout.Label("Día " + e.day + ": " + e.text, st);
            }

            // Debriefing
            if (o.Finished)
            {
                GUILayout.Space(12);
                GUILayout.Label(o.Succeeded ? "MISIÓN EXITOSA" : "MISIÓN FALLIDA", o.Succeeded ? goodStyle : badStyle);

                if (!o.Succeeded)
                {
                    GUILayout.Label("Causa: " + o.FailureCause, label);
                    GUILayout.Space(4);
                    GUILayout.Label("Qué cambiar: " + o.Advice, label);
                }
                else
                {
                    GUILayout.Label("Puntuación de ingeniería: " + o.Score.ToString("F0") + " / 100 (" + o.Rating + ")", header);
                    foreach (string line in o.ScoreLines)
                        GUILayout.Label(line, label);
                }

                GUILayout.Space(10);
                GUILayout.Label("RIESGOS DE TU DISEÑO", header);
                GUILayout.Label(
                    "Tormentas severas esperadas: " + o.ExpectedSevereStorms.ToString("F1") + "\n" +
                    "Riesgo de perder la computadora: " + (o.ComputerLossRisk() * 100f).ToString("F0") + "% (vidas: " + o.ComputerLivesTotal +
                    ", blindaje: " + (o.ShieldingFactor * 100f).ToString("F0") + "%)\n" +
                    "Paneles al final de la misión (esperado): " + (o.ExpectedSolarHealthAtEnd() * 100f).ToString("F0") + "%\n" +
                    "Ciencia que transmite tu antena: " + (o.DataRate * 100f).ToString("F0") + "%", label);
                GUILayout.Label("Los eventos son al azar: la misma nave puede tener buena o mala suerte. Por eso importa el riesgo, no solo el resultado.", label);

                GUILayout.Space(10);
                if (o.Succeeded)
                {
                    if (GUILayout.Button("VER LA PORTADA DEL PERIÓDICO", bigButton, GUILayout.Height(60)))
                        PlayEnding(o);
                    GUILayout.Space(6);
                }
                if (GUILayout.Button("Reintentar con eventos nuevos", button, GUILayout.Height(44)))
                    StartOperation();
                if (GUILayout.Button("Volver al Blueprint", button, GUILayout.Height(44)))
                    tab = 0;
            }
        }

        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

#if UNITY_EDITOR
    // Aparece en el menú de tres puntos (⋮) del componente en el Inspector.
    [ContextMenu("Cargar todo desde Assets")]
    void LoadAllFromAssets()
    {
        availableParts = FindAll<PartData>();
        availableParts.Sort((a, b) => ((int)a.type).CompareTo((int)b.type));

        launchers = FindAll<LauncherData>();
        launchers.Sort((a, b) => a.capacityKg.CompareTo(b.capacityKg));

        orbits = FindAll<OrbitData>();
        orbits.Sort((a, b) => a.altitudeKm.CompareTo(b.altitudeKm));

        briefings = FindAll<MissionBriefing>();
        briefings.Sort((a, b) => a.minSciencePoints.CompareTo(b.minSciencePoints));
        if (briefings.Count > 0) briefing = briefings[Mathf.Min(1, briefings.Count - 1)];

        EditorUtility.SetDirty(this);
        Debug.Log("Cargadas " + availableParts.Count + " piezas, " + launchers.Count + " lanzadores, " + orbits.Count + " órbitas y " + briefings.Count + " misiones.");
    }

    static List<T> FindAll<T>() where T : Object
    {
        var list = new List<T>();
        foreach (var guid in AssetDatabase.FindAssets("t:" + typeof(T).Name))
        {
            var asset = AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guid));
            if (asset != null) list.Add(asset);
        }
        return list;
    }
#endif
}
