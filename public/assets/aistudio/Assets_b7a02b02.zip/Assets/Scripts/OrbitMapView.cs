using UnityEngine;

// Mapa orbital 2D. Se dibuja todo por código (no hay que crear sprites ni objetos a mano).
// BlueprintEditor lo agrega solo a la escena.
// Las texturas (planeta, satélite, sol, estrellas, fondo) vienen de GameVisuals; si faltan, se dibujan reemplazos.
public class OrbitMapView : MonoBehaviour
{
    const float EarthRadiusKm = 6371f;
    const float EarthMu = 398600.4418f; // km^3/s^2
    const float KmPerUnit = 10000f;     // 1 unidad de Unity = 10 000 km

    [Header("Tiempo simulado")]
    [Tooltip("Minutos simulados por cada segundo real (antes del multiplicador)")]
    public float simMinutesPerSecond = 10f;
    public float speedMultiplier = 1f;

    // Datos que lee la interfaz
    public float PeriodMinutes { get; private set; }
    public float EclipseMinutes { get; private set; }
    public float SimTimeMinutes { get; private set; }
    public bool InEclipse { get; private set; }
    public float BatteryWh { get; private set; }
    public float BatteryCapacityWh { get; private set; }
    public float GenerationW { get; private set; }
    public float ConsumptionW { get { return consumptionW; } }
    public bool PowerFailure { get; private set; }

    // 0 = día, 1 = atardecer / amanecer, 2 = noche (eclipse)
    public int EarthPhase { get; private set; }
    public string EarthPhaseName
    {
        get { return EarthPhase == 0 ? "Día" : (EarthPhase == 1 ? "Atardecer / amanecer" : "Noche (eclipse)"); }
    }

    GameVisuals vis;
    Camera cam;
    GameObject root;
    Material lineMat;
    Sprite circleSprite, squareSprite;
    Transform planetRoot, shadow, satellite, sun;
    SpriteRenderer planetNight, planetTwilight, planetDay, satRenderer;
    Color twilightBase, dayBase;
    bool satTextured;
    LineRenderer orbitLine, eclipseLine;
    readonly LineRenderer[] rays = new LineRenderer[5];

    // Fondo y estrellas: van pegados a la cámara (no se mueven ni hacen zoom)
    Transform backdropRoot;
    SpriteRenderer backdrop;
    float backdropAspect = 1f;
    SpriteRenderer[] stars;
    Vector3[] starData;

    float orbitRadius, planetRadius, viewSize, eclipseHalfAngleDeg;
    float angleDeg = 90f;
    float solarW, rtgW, consumptionW;
    bool hasOrbit;
    bool offline;

    void Awake()
    {
        vis = GetComponent<GameVisuals>();
        if (vis == null) vis = gameObject.AddComponent<GameVisuals>();

        cam = Camera.main;
        if (cam != null)
        {
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.03f, 0.04f, 0.08f);
        }

        Shader sh = Shader.Find("Sprites/Default");
        if (sh == null) sh = Shader.Find("Unlit/Color");
        lineMat = new Material(sh);

        circleSprite = MakeCircleSprite();
        squareSprite = MakeSquareSprite();

        root = new GameObject("MapaOrbital");

        shadow = MakeSprite("Sombra", squareSprite, new Color(0.25f, 0.15f, 0.45f, 0.55f), 0).transform;

        // --- Planeta Tierra: 3 capas (noche abajo, atardecer en medio, día arriba) ---
        planetRoot = new GameObject("Planeta").transform;
        planetRoot.SetParent(root.transform, false);

        Color nightBase = (vis.earthNight != null) ? Color.white : new Color(0.05f, 0.07f, 0.22f);
        twilightBase = (vis.earthTwilight != null) ? Color.white : new Color(0.95f, 0.5f, 0.15f);
        dayBase = (vis.earthDay != null) ? Color.white : new Color(0.15f, 0.45f, 0.9f);

        planetNight = MakeSprite("Noche", PlanetSprite(vis.earthNight), nightBase, 1);
        planetTwilight = MakeSprite("Atardecer", PlanetSprite(vis.earthTwilight), twilightBase, 2);
        planetDay = MakeSprite("Dia", PlanetSprite(vis.earthDay), dayBase, 3);
        planetNight.transform.SetParent(planetRoot, false);
        planetTwilight.transform.SetParent(planetRoot, false);
        planetDay.transform.SetParent(planetRoot, false);

        // --- Sol ---
        bool sunTex = vis.sun != null;
        SpriteRenderer sunSr = MakeSprite("Sol", sunTex ? GameVisuals.MakeSprite(vis.sun) : circleSprite,
                                          sunTex ? Color.white : new Color(1f, 0.85f, 0.2f), 5);
        sun = sunSr.transform;

        // --- Satélite ---
        satTextured = vis.satellite != null;
        satRenderer = MakeSprite("Satelite", satTextured ? GameVisuals.MakeSprite(vis.satellite) : circleSprite, Color.white, 8);
        satellite = satRenderer.transform;

        // --- Líneas ---
        orbitLine = MakeLine("Orbita", new Color(0.3f, 0.75f, 1f, 0.9f), 6);
        orbitLine.loop = true;
        eclipseLine = MakeLine("ArcoEclipse", new Color(1f, 0.45f, 0.1f, 1f), 7);
        for (int i = 0; i < rays.Length; i++)
            rays[i] = MakeLine("Rayo" + i, new Color(1f, 0.85f, 0.2f, 0.8f), 4);

        BuildBackdrop();
    }

    Sprite PlanetSprite(Texture2D tex)
    {
        return (tex != null) ? GameVisuals.MakeSprite(tex) : circleSprite;
    }

    void BuildBackdrop()
    {
        if (cam == null) return;

        backdropRoot = new GameObject("FondoMapa").transform;
        backdropRoot.SetParent(cam.transform, false);
        backdropRoot.localPosition = new Vector3(0f, 0f, 40f);

        if (vis.mapBackground != null)
        {
            var go = new GameObject("Fondo");
            go.transform.SetParent(backdropRoot, false);
            backdrop = go.AddComponent<SpriteRenderer>();
            backdrop.sprite = GameVisuals.MakeSprite(vis.mapBackground);
            backdrop.sortingOrder = -20;
            backdropAspect = vis.mapBackground.width / (float)vis.mapBackground.height;
        }

        Sprite starSprite = (vis.star != null) ? GameVisuals.MakeSprite(vis.star) : circleSprite;
        var rng = new System.Random(11);
        int n = 70;
        stars = new SpriteRenderer[n];
        starData = new Vector3[n];
        for (int i = 0; i < n; i++)
        {
            starData[i] = new Vector3((float)rng.NextDouble(), (float)rng.NextDouble(), (float)rng.NextDouble() * 6.28f);
            var go = new GameObject("Estrella");
            go.transform.SetParent(backdropRoot, false);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = starSprite;
            sr.sortingOrder = -15;
            stars[i] = sr;
        }
    }

    void OnDestroy()
    {
        if (root != null) Destroy(root);
        if (backdropRoot != null) Destroy(backdropRoot.gameObject);
    }

    // ---------- API pública ----------

    // Se oculta el fondo del mapa cuando se muestra la escena de lanzamiento.
    public void SetBackdropVisible(bool visible)
    {
        if (backdropRoot != null) backdropRoot.gameObject.SetActive(visible);
    }

    public void SetOrbit(OrbitData orbit)
    {
        hasOrbit = orbit != null;
        if (!hasOrbit) return;

        float rKm = EarthRadiusKm + orbit.altitudeKm;
        orbitRadius = rKm / KmPerUnit;
        planetRadius = EarthRadiusKm / KmPerUnit;

        float periodSec = 2f * Mathf.PI * Mathf.Sqrt((rKm * rKm * rKm) / EarthMu);
        PeriodMinutes = periodSec / 60f;

        float theta = Mathf.Asin(EarthRadiusKm / rKm);        // radianes
        eclipseHalfAngleDeg = theta * Mathf.Rad2Deg;
        EclipseMinutes = PeriodMinutes * theta / Mathf.PI;     // misma fórmula que MissionCalculator

        viewSize = orbitRadius * 1.35f;
        float lineW = viewSize * 0.012f;

        // Planeta y sombra (la luz del Sol llega desde ARRIBA, la sombra cae hacia abajo)
        planetRoot.localScale = Vector3.one * (planetRadius * 2f);
        float shadowLen = orbitRadius * 3f;
        shadow.localScale = new Vector3(planetRadius * 2f, shadowLen, 1f);
        shadow.localPosition = new Vector3(0f, -shadowLen / 2f, 0f);

        // Órbita (círculo)
        int n = 128;
        orbitLine.positionCount = n;
        for (int i = 0; i < n; i++)
        {
            float a = 2f * Mathf.PI * i / n;
            orbitLine.SetPosition(i, new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0f) * orbitRadius);
        }
        orbitLine.startWidth = orbitLine.endWidth = lineW;

        // Arco de eclipse: centrado en -90° (abajo), mismo ancho que la sombra del planeta
        int m = 48;
        eclipseLine.positionCount = m + 1;
        for (int i = 0; i <= m; i++)
        {
            float a = (-90f - eclipseHalfAngleDeg + 2f * eclipseHalfAngleDeg * i / m) * Mathf.Deg2Rad;
            eclipseLine.SetPosition(i, new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0f) * orbitRadius);
        }
        eclipseLine.startWidth = eclipseLine.endWidth = lineW * 2.4f;

        // Sol y rayos
        sun.localPosition = new Vector3(0f, viewSize * 0.94f, 0f);
        sun.localScale = Vector3.one * (viewSize * (vis.sun != null ? 0.12f : 0.08f));
        for (int i = 0; i < rays.Length; i++)
        {
            float x = (i - 2) * planetRadius * 0.4f;
            rays[i].positionCount = 2;
            rays[i].SetPosition(0, new Vector3(x, viewSize * 0.88f, 0f));
            rays[i].SetPosition(1, new Vector3(x, viewSize * 0.78f, 0f));
            rays[i].startWidth = rays[i].endWidth = viewSize * 0.006f;
        }

        satellite.localScale = Vector3.one * (viewSize * (satTextured ? 0.07f : 0.05f));
        UpdateEarthPhase();
    }

    // Se llama cada vez que cambia el diseño: reinicia la simulación de energía.
    public void SetPower(float solarWatts, float rtgWatts, float consumptionWatts, float batteryCapacityWh)
    {
        solarW = solarWatts;
        rtgW = rtgWatts;
        consumptionW = consumptionWatts;
        BatteryCapacityWh = batteryCapacityWh;
        BatteryWh = batteryCapacityWh;
        PowerFailure = false;
        SimTimeMinutes = 0f;
    }

    // Para la fase de operación: cambia la potencia sin reiniciar la batería ni el reloj.
    public void UpdatePower(float solarWatts, float rtgWatts, float consumptionWatts)
    {
        solarW = solarWatts;
        rtgW = rtgWatts;
        consumptionW = consumptionWatts;
    }

    // La nave se muestra en gris cuando está fuera de servicio.
    public void SetOffline(bool value)
    {
        offline = value;
    }

    // ---------- Simulación ----------

    void Update()
    {
        if (hasOrbit && PeriodMinutes > 0f) StepSimulation();
        UpdateBackdrop();
    }

    void StepSimulation()
    {
        // La cámara se ajusta a la órbita y la desplaza a la derecha (el panel izquierdo ocupa el 25 %)
        if (cam != null)
        {
            cam.orthographicSize = viewSize;
            float halfWidth = viewSize * cam.aspect;
            cam.transform.position = new Vector3(-0.25f * halfWidth, 0f, -10f);
        }

        float dtMin = Time.deltaTime * simMinutesPerSecond * speedMultiplier;
        SimTimeMinutes += dtMin;

        angleDeg = Mathf.Repeat(angleDeg + 360f * dtMin / PeriodMinutes, 360f);
        float a = angleDeg * Mathf.Deg2Rad;
        satellite.localPosition = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0f) * orbitRadius;
        if (satTextured) satellite.localRotation = Quaternion.Euler(0f, 0f, angleDeg - 90f);

        InEclipse = Mathf.Abs(Mathf.DeltaAngle(angleDeg, -90f)) < eclipseHalfAngleDeg;
        UpdateEarthPhase();

        // Balance de energía
        GenerationW = InEclipse ? rtgW : (solarW + rtgW);
        float netW = GenerationW - consumptionW;
        BatteryWh = Mathf.Clamp(BatteryWh + netW * dtMin / 60f, 0f, BatteryCapacityWh);
        if (netW < 0f && BatteryWh <= 0f) PowerFailure = true;

        bool dead = PowerFailure || offline;
        if (satTextured)
        {
            if (dead) satRenderer.color = new Color(0.35f, 0.35f, 0.35f);
            else if (InEclipse) satRenderer.color = new Color(0.65f, 0.65f, 0.8f);
            else satRenderer.color = Color.white;
        }
        else
        {
            if (dead) satRenderer.color = new Color(0.5f, 0.5f, 0.5f);
            else if (InEclipse) satRenderer.color = new Color(1f, 0.45f, 0.1f);
            else satRenderer.color = new Color(0.3f, 1f, 0.4f);
        }
    }

    // La Tierra cambia según dónde está la nave respecto a la sombra:
    //   lejos de la sombra = DÍA, cerca del borde de la sombra = ATARDECER / AMANECER, dentro = NOCHE.
    // La transición se centra en el límite de la sombra (terminador) y usa curvas suaves (SmoothStep)
    // para que el paso entre noche, amanecer/atardecer y día sea progresivo y natural.
    void UpdateEarthPhase()
    {
        if (planetDay == null) return;

        float d = Mathf.Abs(Mathf.DeltaAngle(angleDeg, -90f));        // distancia angular al centro de la sombra
        float width = Mathf.Max(10f, vis.twilightDegrees);

        // La mitad de la transición ocurre dentro de la sombra y la otra mitad en la luz
        float halfW = Mathf.Min(width * 0.5f, eclipseHalfAngleDeg > 0f ? eclipseHalfAngleDeg * 0.85f : width * 0.5f);
        float delta = d - eclipseHalfAngleDeg; // <0 dentro de sombra, >0 iluminado por el sol
        float x = delta / halfW;              // -1 = noche plena, 0 = terminador (pico atardecer/amanecer), +1 = día pleno

        float aTwilight;
        float aDay;

        if (x <= -1f)
        {
            // Noche plena dentro del cono de sombra
            aTwilight = 0f;
            aDay = 0f;
        }
        else if (x < 0f)
        {
            // Transición suave Noche <-> Atardecer/Amanecer
            float tNorm = Mathf.InverseLerp(-1f, 0f, x);
            aTwilight = Mathf.SmoothStep(0f, 1f, tNorm);
            aDay = 0f;
        }
        else if (x < 1f)
        {
            // Transición suave Atardecer/Amanecer <-> Día
            float tNorm = Mathf.InverseLerp(0f, 1f, x);
            aTwilight = 1f;
            aDay = Mathf.SmoothStep(0f, 1f, tNorm);
        }
        else
        {
            // Día pleno
            aTwilight = 1f;
            aDay = 1f;
        }

        Color t = twilightBase; t.a = aTwilight;
        Color dd = dayBase; dd.a = aDay;
        planetTwilight.color = t;
        planetDay.color = dd;

        EarthPhase = (x < -0.3f) ? 2 : (x < 0.3f ? 1 : 0);
    }

    // Fondo y estrellas pegados a la cámara
    void UpdateBackdrop()
    {
        if (cam == null || backdropRoot == null || !backdropRoot.gameObject.activeInHierarchy) return;

        float viewH = cam.orthographicSize * 2f;
        float viewW = viewH * cam.aspect;

        if (backdrop != null)
        {
            float s = Mathf.Max(viewH, viewW / backdropAspect);
            backdrop.transform.localScale = new Vector3(s, s, 1f);
        }

        bool starTex = vis.star != null;
        for (int i = 0; i < stars.Length; i++)
        {
            Vector3 d = starData[i];
            stars[i].transform.localPosition = new Vector3((d.x - 0.5f) * viewW, (d.y - 0.5f) * viewH, 0f);
            float size = starTex ? viewH * 0.025f : viewH * (0.004f + 0.003f * (i % 3));
            stars[i].transform.localScale = Vector3.one * size;
            float tw = 0.35f + 0.65f * (0.5f + 0.5f * Mathf.Sin(Time.time * 2f + d.z));
            stars[i].color = new Color(1f, 1f, 1f, tw);
        }
    }

    // ---------- Utilidades para dibujar ----------

    SpriteRenderer MakeSprite(string objName, Sprite sprite, Color color, int order)
    {
        var go = new GameObject(objName);
        go.transform.SetParent(root.transform, false);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        return sr;
    }

    LineRenderer MakeLine(string objName, Color color, int order)
    {
        var go = new GameObject(objName);
        go.transform.SetParent(root.transform, false);
        var lr = go.AddComponent<LineRenderer>();
        lr.useWorldSpace = false;
        lr.material = lineMat;
        lr.startColor = color;
        lr.endColor = color;
        lr.sortingOrder = order;
        lr.numCapVertices = 2;
        lr.positionCount = 0;
        return lr;
    }

    static Sprite MakeCircleSprite()
    {
        int size = 128;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        float r = size / 2f;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(r, r));
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, Mathf.Clamp01(r - d)));
            }
        }
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size); // 1 unidad de diámetro
    }

    static Sprite MakeSquareSprite()
    {
        var tex = new Texture2D(4, 4, TextureFormat.RGBA32, false);
        for (int y = 0; y < 4; y++)
            for (int x = 0; x < 4; x++)
                tex.SetPixel(x, y, Color.white);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f), 4); // 1 x 1 unidad
    }
}
