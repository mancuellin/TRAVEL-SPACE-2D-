#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

// Crea los assets de ejemplo con un clic. NO sobrescribe los que ya existen:
// solo crea los que faltan (así puedes volver a ejecutarlo sin perder tus cambios).
// IMPORTANTE: debe estar dentro de una carpeta llamada "Editor".
public static class CreateSampleData
{
    const string Folder = "Assets/Data";

    [MenuItem("Orbital Trade-Off/Crear datos de ejemplo")]
    public static void Create()
    {
        if (!AssetDatabase.IsValidFolder(Folder))
            AssetDatabase.CreateFolder("Assets", "Data");

        //          nombre                    tipo                 masa  costo potencia bateria combustible ciencia
        MakePart("Estructura",              PartType.Structure,  100f, 3f,   0f,     0f,     0f,         0f);
        MakePart("Computadora simple",      PartType.Computer,   5f,   1f,   -30f,   0f,     0f,         0f, 0.5f, 1);
        MakePart("Antena omni",             PartType.Antenna,    2f,   0.5f, -10f,   0f,     0f,         0f, 0.5f);
        MakePart("Camara HD",               PartType.Instrument, 25f,  6f,   -80f,   0f,     0f,         50f);
        MakePart("Panel solar",             PartType.SolarPanel, 15f,  1.5f, 200f,   0f,     0f,         0f);
        MakePart("Bateria",                 PartType.Battery,    10f,  1f,   0f,     150f,   0f,         0f);
        MakePart("Tanque",                  PartType.Fuel,       20f,  1f,   0f,     0f,     100f,       0f);

        // Piezas nuevas (fase de operación)
        MakePart("Antena parabolica",       PartType.Antenna,    12f,  3f,   -60f,   0f,     0f,         0f, 1.0f);
        MakePart("Computadora redundante",  PartType.Computer,   9f,   3f,   -45f,   0f,     0f,         0f, 0.5f, 2);
        MakePart("Blindaje",                PartType.Shielding,  15f,  1.5f, 0f,     0f,     0f,         0f, 0.5f, 1, 0.3f);
        MakePart("RTG",                     PartType.RTG,        40f,  12f,  120f,   0f,     0f,         0f);
        MakePart("Radar",                   PartType.Instrument, 40f,  9f,   -150f,  0f,     0f,         70f);

        MakeLauncher("Lanzador Ligero", 500f, 15f);
        MakeLauncher("Lanzador Medio", 1200f, 35f);
        MakeLauncher("Lanzador Pesado", 2000f, 60f);

        MakeOrbit("LEO", 400f, 100f);
        MakeOrbit("MEO", 20000f, 2200f);
        MakeOrbit("GEO", 35786f, 3900f);

        var b = ScriptableObject.CreateInstance<MissionBriefing>();
        b.title = "Mision de prueba";
        b.description = "Observa la Tierra con camara HD sin pasarte del presupuesto.";
        b.budgetMillions = 40f;
        b.minSciencePoints = 40f;
        b.missionDays = 180f;
        Save(b, "Briefing de prueba");

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Datos de ejemplo listos en " + Folder + " (solo se crearon los que faltaban).");
    }

    static void MakePart(string name, PartType type, float mass, float cost, float power, float battery, float fuel, float science,
                         float dataRate = 0.5f, int lives = 1, float shield = 0f)
    {
        var p = ScriptableObject.CreateInstance<PartData>();
        p.partName = name;
        p.type = type;
        p.massKg = mass;
        p.costMillions = cost;
        p.powerWatts = power;
        p.batteryWh = battery;
        p.fuelKg = fuel;
        p.sciencePoints = science;
        p.dataRate = dataRate;
        p.computerLives = lives;
        p.shielding = shield;
        Save(p, name);
    }

    static void MakeLauncher(string name, float capacity, float cost)
    {
        var l = ScriptableObject.CreateInstance<LauncherData>();
        l.launcherName = name;
        l.capacityKg = capacity;
        l.costMillions = cost;
        Save(l, name);
    }

    static void MakeOrbit(string name, float altitudeKm, float deltaV)
    {
        var o = ScriptableObject.CreateInstance<OrbitData>();
        o.orbitName = name;
        o.altitudeKm = altitudeKm;
        o.deltaVRequired = deltaV;
        Save(o, name);
    }

    static void Save(Object obj, string fileName)
    {
        string path = Folder + "/" + fileName + ".asset";
        if (AssetDatabase.LoadAssetAtPath<Object>(path) != null)
        {
            Object.DestroyImmediate(obj); // ya existe: no lo sobrescribimos
            return;
        }
        AssetDatabase.CreateAsset(obj, path);
    }
}
#endif
