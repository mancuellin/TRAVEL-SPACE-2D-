using UnityEngine;

[CreateAssetMenu(fileName = "NewBriefing", menuName = "Orbital Trade-Off/Mission Briefing")]
public class MissionBriefing : ScriptableObject
{
    public string title = "Nueva misión";
    [TextArea] public string description;
    [Tooltip("Presupuesto máximo en millones de dólares")]
    public float budgetMillions = 40f;
    [Tooltip("Puntos de ciencia mínimos que deben LLEGAR a la Tierra para considerar la misión exitosa")]
    public float minSciencePoints = 40f;
    [Tooltip("Vida útil que debe sobrevivir la nave, en días")]
    public float missionDays = 180f;
}
