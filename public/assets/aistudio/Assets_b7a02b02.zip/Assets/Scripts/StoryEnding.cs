using System.Collections.Generic;
using UnityEngine;

// FINAL DEL JUEGO
// Portada de periódico con John (traje espacial + casco), el titular y frases de varias personas.
// Se muestra cuando la misión termina con éxito.
//
// - La imagen es OPCIONAL: si dejas "John Suit" vacío, se dibuja un reemplazo.
// - Los TEXTOS están en este archivo (campos de arriba y método BuildQuotes()). Edítalos libremente.
public class StoryEnding : MonoBehaviour
{
    // ============================================================
    //  IMAGEN
    // ============================================================
    [Header("IMAGEN (arrástrala aquí)")]
    [Tooltip("John con su traje espacial sosteniendo el casco en la mano")]
    public Texture2D johnSuit;

    // ============================================================
    //  TEXTOS DEL PERIÓDICO
    // ============================================================
    [Header("TEXTOS DEL PERIÓDICO")]
    public string newspaperName = "EL DIARIO DEL ESPACIO";
    public string headline = "PRIMER JOVEN LOGRA CON ÉXITO SU PRIMER VIAJE FUERA DEL PLANETA TIERRA";
    public string photoCaption = "John, de 21 años, con su traje espacial y su casco, tras completar su histórica misión.";
    public string johnName = "John";

    // ============================================================
    //  USO INTERNO
    // ============================================================
    enum Phase { Paper, Credits }

    class Quote
    {
        public string who;
        public string text;
    }

    public bool IsPlaying { get; private set; }

    // true = volver al menú principal, false = seguir jugando
    public System.Action<bool> OnFinished;

    readonly List<Quote> quotes = new List<Quote>();
    Vector3[] stars;

    Phase phase;
    float t;           // tiempo desde que empezó el final
    float phaseTime;   // tiempo dentro de la fase actual

    string mission = "";
    string orbit = "";
    int days;
    float science;
    float score;
    string rating = "";

    const float SpinSeconds = 1.3f;
    const float FirstQuoteAt = 2.0f;
    const float QuoteGap = 0.85f;

    static readonly Color Ink = new Color(0.12f, 0.11f, 0.10f);
    static readonly Color Paper = new Color(0.93f, 0.90f, 0.80f);

    GUIStyle mastStyle, subStyle, headlineStyle, bodyStyle, quoteStyle, whoStyle, bigQuoteStyle;
    GUIStyle captionStyle, hintStyle, titleStyle, finStyle, creditStyle, btnStyle, placeholderStyle;

    void Awake()
    {
        BuildQuotes();

        var rng = new System.Random(5);
        stars = new Vector3[90];
        for (int i = 0; i < stars.Length; i++)
            stars[i] = new Vector3((float)rng.NextDouble(), (float)rng.NextDouble(), (float)rng.NextDouble() * 6.28f);
    }

    // ------------------------------------------------------------
    //  LAS FRASES (edita aquí: quién lo dice y qué dice)
    // ------------------------------------------------------------
    void BuildQuotes()
    {
        quotes.Clear();
        AddQuote("El Presidente",
            "Hoy el mundo entero mira al cielo con orgullo. John demuestra que los sueños no tienen frontera.");
        AddQuote("Director de la NASA",
            "Su diseño fue un ejemplo de equilibrio entre presupuesto, masa y energía. Estamos muy orgullosos.");
        AddQuote("Mamá de John",
            "Siempre supe que llegaría lejos. ¡Qué orgullo, hijo!");
        AddQuote("Papá de John",
            "Estudió mucho para esto. Hoy toda la familia celebra su logro.");
        AddQuote("Ministro de Ciencia",
            "Su misión abre la puerta a una nueva generación de jóvenes científicos e ingenieros.");
        AddQuote("Una estudiante",
            "Quiero ser como John cuando sea grande. ¡Yo también voy a viajar al espacio!");
    }

    void AddQuote(string who, string text)
    {
        quotes.Add(new Quote { who = who, text = text });
    }

    // ------------------------------------------------------------
    //  CONTROL
    // ------------------------------------------------------------
    public void Play(string missionTitle, string orbitName, int missionDays, float scienceDelivered, float engineeringScore, string engineeringRating)
    {
        if (quotes.Count == 0) BuildQuotes();

        mission = missionTitle;
        orbit = orbitName;
        days = missionDays;
        science = scienceDelivered;
        score = engineeringScore;
        rating = engineeringRating;

        t = 0f;
        phaseTime = 0f;
        phase = Phase.Paper;
        IsPlaying = true;
    }

    void Finish(bool toMenu)
    {
        IsPlaying = false;
        if (OnFinished != null) OnFinished(toMenu);
    }

    float RevealEnd
    {
        get { return FirstQuoteAt + QuoteGap * Mathf.Max(0, quotes.Count - 1) + 0.7f; }
    }

    void Update()
    {
        if (!IsPlaying) return;
        t += Time.deltaTime;
        phaseTime += Time.deltaTime;
    }

    void Advance()
    {
        if (phase != Phase.Paper) return;

        if (t < RevealEnd)
        {
            t = RevealEnd; // mostrar todas las frases de una vez
            return;
        }
        phase = Phase.Credits;
        phaseTime = 0f;
    }

    // ------------------------------------------------------------
    //  DIBUJO (lo llama BlueprintEditor desde su OnGUI)
    // ------------------------------------------------------------
    public void Draw(float w, float h)
    {
        if (!IsPlaying) return;
        InitStyles(h);

        if (phase == Phase.Paper) DrawPaperPhase(w, h);
        else DrawCreditsPhase(w, h);
    }

    void DrawPaperPhase(float w, float h)
    {
        Fill(new Rect(0, 0, w, h), new Color(0.04f, 0.05f, 0.08f));
        DrawStars(w, h, 0.5f);

        DrawNewspaper(w, h);

        if (t >= RevealEnd)
        {
            float a = 0.5f + 0.5f * Mathf.Sin(Time.time * 4f);
            GUI.color = new Color(1f, 1f, 1f, a);
            GUI.Label(new Rect(0f, h - 34f, w - 24f, 28f), "ESPACIO o CLIC para continuar", hintStyle);
            GUI.color = Color.white;
        }

        Event e = Event.current;
        if (e.type == EventType.KeyDown &&
            (e.keyCode == KeyCode.Space || e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
        {
            Advance();
            e.Use();
        }
        else if (e.type == EventType.MouseDown && e.button == 0)
        {
            Advance();
            e.Use();
        }
    }

    void DrawNewspaper(float w, float h)
    {
        // Entrada: el periódico gira y se acerca (como en las películas)
        float k = Mathf.Clamp01(t / SpinSeconds);
        float ease = 1f - Mathf.Pow(1f - k, 3f);
        bool animating = k < 1f;

        Matrix4x4 oldMatrix = GUI.matrix;
        if (animating)
        {
            Vector2 pivot = new Vector2(w / 2f, h / 2f);
            GUIUtility.ScaleAroundPivot(Vector2.one * Mathf.Lerp(0.05f, 1f, ease), pivot);
            GUIUtility.RotateAroundPivot((1f - ease) * 900f, pivot);
        }

        float pageH = h * 0.92f;
        float pageW = Mathf.Min(w * 0.94f, pageH * 1.55f);
        Rect page = new Rect((w - pageW) / 2f, (h - pageH) / 2f, pageW, pageH);

        // Sombra y hoja
        Fill(new Rect(page.x + 10f, page.y + 10f, page.width, page.height), new Color(0f, 0f, 0f, 0.45f));
        Fill(page, Paper);

        float pad = pageW * 0.025f;
        Rect inner = new Rect(page.x + pad, page.y + pad * 0.6f, page.width - pad * 2f, page.height - pad * 1.2f);

        // --- Cabecera ---
        Rect mast = new Rect(inner.x, inner.y, inner.width, inner.height * 0.12f);
        GUI.Label(mast, newspaperName, mastStyle);
        Fill(new Rect(inner.x, mast.yMax, inner.width, 3f), Ink);

        Rect sub = new Rect(inner.x, mast.yMax + 3f, inner.width, inner.height * 0.035f);
        GUI.Label(sub, "EDICIÓN ESPECIAL  -  AÑO 1  -  N.º 1  -  PRECIO: UN SUEÑO CUMPLIDO", subStyle);
        Fill(new Rect(inner.x, sub.yMax, inner.width, 1.5f), Ink);

        // --- Titular ---
        Rect head = new Rect(inner.x, sub.yMax + 6f, inner.width, inner.height * 0.17f);
        GUI.Label(head, headline, headlineStyle);
        Fill(new Rect(inner.x, head.yMax, inner.width, 3f), Ink);

        // --- Cuerpo: foto a la izquierda, texto y frases a la derecha ---
        float y0 = head.yMax + 10f;
        float bodyH = inner.yMax - y0;
        float leftW = inner.width * 0.33f;

        Rect frame = new Rect(inner.x, y0, leftW, bodyH * 0.78f);
        Fill(frame, Ink);
        Rect photo = new Rect(frame.x + 4f, frame.y + 4f, frame.width - 8f, frame.height - 8f);
        Fill(photo, new Color(0.80f, 0.78f, 0.70f));
        if (johnSuit != null) GUI.DrawTexture(photo, johnSuit, ScaleMode.ScaleToFit, true);
        else DrawPlaceholderPhoto(photo);

        GUI.Label(new Rect(inner.x, frame.yMax + 4f, leftW, bodyH * 0.22f - 4f), photoCaption, captionStyle);

        Fill(new Rect(inner.x + leftW + pad * 0.5f, y0, 1.5f, bodyH), Ink);

        Rect right = new Rect(inner.x + leftW + pad, y0, inner.width - leftW - pad, bodyH);

        string blurb = johnName + ", de 21 años, completó la misión «" + mission + "» en órbita " + orbit + ": " +
                       days + " días de operación y " + science.ToString("F0") + " puntos de ciencia enviados a la Tierra. " +
                       "Puntuación de ingeniería: " + score.ToString("F0") + "/100 (" + rating + ").";
        GUI.Label(new Rect(right.x, right.y, right.width, bodyH * 0.24f), blurb, bodyStyle);

        // --- Frases (2 columnas x 3 filas), aparecen una por una ---
        Rect area = new Rect(right.x, right.y + bodyH * 0.26f, right.width, bodyH * 0.74f);
        float gap = 12f;
        float cw = (area.width - gap) / 2f;
        float ch = (area.height - gap * 2f) / 3f;

        for (int i = 0; i < quotes.Count && i < 6; i++)
        {
            float a = Mathf.Clamp01((t - (FirstQuoteAt + QuoteGap * i)) / 0.5f);
            if (a <= 0f) continue;

            int col = i % 2;
            int row = i / 2;
            Rect c = new Rect(area.x + col * (cw + gap), area.y + row * (ch + gap) + (1f - a) * 12f, cw, ch);

            Fill(c, new Color(0.86f, 0.83f, 0.72f, a));
            Fill(new Rect(c.x, c.y, 5f, c.height), new Color(1f, 0.5f, 0.1f, a));

            GUI.color = new Color(1f, 1f, 1f, a);
            GUI.Label(new Rect(c.x + 10f, c.y - h * 0.012f, 50f, h * 0.07f), "\u201C", bigQuoteStyle);
            GUI.Label(new Rect(c.x + 14f, c.y + h * 0.026f, c.width - 24f, c.height - h * 0.062f), quotes[i].text, quoteStyle);
            GUI.Label(new Rect(c.x + 14f, c.yMax - h * 0.034f, c.width - 24f, h * 0.03f), "- " + quotes[i].who, whoStyle);
            GUI.color = Color.white;
        }

        GUI.matrix = oldMatrix;
    }

    void DrawPlaceholderPhoto(Rect r)
    {
        Fill(r, new Color(0.62f, 0.66f, 0.74f));
        Fill(new Rect(r.x + r.width * 0.25f, r.y + r.height * 0.38f, r.width * 0.50f, r.height * 0.60f), new Color(0.92f, 0.92f, 0.96f)); // traje
        Fill(new Rect(r.x + r.width * 0.35f, r.y + r.height * 0.12f, r.width * 0.30f, r.height * 0.24f), new Color(0.95f, 0.8f, 0.65f));  // cabeza
        Rect helmet = new Rect(r.x + r.width * 0.70f, r.y + r.height * 0.50f, r.width * 0.22f, r.height * 0.20f);                           // casco
        Fill(helmet, new Color(0.85f, 0.88f, 0.95f));
        Fill(new Rect(helmet.x + helmet.width * 0.15f, helmet.y + helmet.height * 0.25f, helmet.width * 0.7f, helmet.height * 0.4f), new Color(0.2f, 0.3f, 0.5f));
        GUI.Label(new Rect(r.x, r.yMax - h2(r) , r.width, h2(r)), "(foto de ejemplo: arrastra tu imagen a «John Suit»)", placeholderStyle);
    }

    static float h2(Rect r) { return Mathf.Min(40f, r.height * 0.12f); }

    // ---------- Créditos ----------

    void DrawCreditsPhase(float w, float h)
    {
        Fill(new Rect(0, 0, w, h), new Color(0.03f, 0.04f, 0.08f));
        DrawStars(w, h, 1f);

        float a = Mathf.Clamp01(phaseTime / 0.8f);
        GUI.color = new Color(1f, 1f, 1f, a);

        GUI.Label(new Rect(0f, h * 0.12f, w, h * 0.12f), "THE TRAVEL SPACE 2D", titleStyle);
        GUI.Label(new Rect(0f, h * 0.24f, w, h * 0.20f), "FIN", finStyle);
        GUI.Label(new Rect(0f, h * 0.46f, w, h * 0.06f), "Gracias por jugar", creditStyle);
        GUI.Label(new Rect(0f, h * 0.54f, w, h * 0.10f),
                  "Misión: " + mission + "  |  Órbita: " + orbit + "\nPuntuación de ingeniería: " + score.ToString("F0") + "/100 (" + rating + ")",
                  creditStyle);

        float bw = Mathf.Min(300f, w * 0.3f);
        float by = h * 0.74f;
        if (GUI.Button(new Rect(w / 2f - bw - 10f, by, bw, 60f), "VOLVER AL MENÚ", btnStyle))
        {
            Finish(true);
            GUI.color = Color.white;
            return;
        }
        if (GUI.Button(new Rect(w / 2f + 10f, by, bw, 60f), "SEGUIR JUGANDO", btnStyle))
        {
            Finish(false);
            GUI.color = Color.white;
            return;
        }
        GUI.color = Color.white;
    }

    void DrawStars(float w, float h, float brightness)
    {
        for (int i = 0; i < stars.Length; i++)
        {
            float twinkle = 0.35f + 0.65f * (0.5f + 0.5f * Mathf.Sin(Time.time * 2f + stars[i].z));
            float s = 2f + (i % 3);
            Fill(new Rect(stars[i].x * w, stars[i].y * h, s, s), new Color(1f, 1f, 1f, twinkle * brightness));
        }
    }

    static void Fill(Rect r, Color c)
    {
        GUI.color = c;
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = Color.white;
    }

    void InitStyles(float h)
    {
        if (mastStyle == null)
        {
            mastStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            mastStyle.normal.textColor = Ink;

            subStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter };
            subStyle.normal.textColor = Ink;

            headlineStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, wordWrap = true };
            headlineStyle.normal.textColor = Ink;

            bodyStyle = new GUIStyle(GUI.skin.label) { wordWrap = true };
            bodyStyle.normal.textColor = Ink;

            quoteStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Italic, wordWrap = true };
            quoteStyle.normal.textColor = Ink;

            whoStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.LowerRight };
            whoStyle.normal.textColor = new Color(0.55f, 0.25f, 0.05f);

            bigQuoteStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold };
            bigQuoteStyle.normal.textColor = new Color(1f, 0.5f, 0.1f);

            captionStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Italic, wordWrap = true };
            captionStyle.normal.textColor = new Color(0.25f, 0.23f, 0.2f);

            hintStyle = new GUIStyle(GUI.skin.label) { fontSize = 14, alignment = TextAnchor.LowerRight };
            hintStyle.normal.textColor = new Color(0.6f, 0.85f, 1f);

            titleStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            titleStyle.normal.textColor = new Color(0.25f, 0.75f, 1f);

            finStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            finStyle.normal.textColor = Color.white;

            creditStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, wordWrap = true };
            creditStyle.normal.textColor = new Color(0.75f, 0.8f, 0.9f);

            placeholderStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.LowerCenter, wordWrap = true };
            placeholderStyle.normal.textColor = new Color(0.1f, 0.1f, 0.15f, 0.8f);

            btnStyle = new GUIStyle(GUI.skin.button) { fontSize = 20, fontStyle = FontStyle.Bold };
        }

        // Los tamaños de letra se adaptan al alto de la pantalla
        mastStyle.fontSize = Mathf.Max(24, Mathf.RoundToInt(h * 0.062f));
        subStyle.fontSize = Mathf.Max(11, Mathf.RoundToInt(h * 0.017f));
        headlineStyle.fontSize = Mathf.Max(20, Mathf.RoundToInt(h * 0.050f));
        bodyStyle.fontSize = Mathf.Max(13, Mathf.RoundToInt(h * 0.0225f));
        quoteStyle.fontSize = Mathf.Max(13, Mathf.RoundToInt(h * 0.0215f));
        whoStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(h * 0.0195f));
        bigQuoteStyle.fontSize = Mathf.Max(28, Mathf.RoundToInt(h * 0.06f));
        captionStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(h * 0.0195f));
        titleStyle.fontSize = Mathf.Max(28, Mathf.RoundToInt(h * 0.07f));
        finStyle.fontSize = Mathf.Max(60, Mathf.RoundToInt(h * 0.16f));
        creditStyle.fontSize = Mathf.Max(16, Mathf.RoundToInt(h * 0.03f));
        placeholderStyle.fontSize = Mathf.Max(11, Mathf.RoundToInt(h * 0.017f));
    }
}
