using System.Collections.Generic;
using UnityEngine;

// Script de prueba: muestra el resultado en pantalla sin necesidad de crear UI.
// Se pone en un GameObject vacío de la escena.
public class MissionTester : MonoBehaviour
{
    [Header("Arrastra aquí tus assets")]
    public MissionBriefing briefing;
    public LauncherData launcher;
    public OrbitData orbit;
    [Tooltip("Puedes repetir la misma pieza varias veces (ej. 2 paneles solares)")]
    public List<PartData> parts = new List<PartData>();

    MissionResult result;
    GUIStyle labelStyle;

    void Start()
    {
        Recalculate();
    }

    [ContextMenu("Recalcular")]
    public void Recalculate()
    {
        result = MissionCalculator.Calculate(parts, launcher, orbit, briefing);
    }

    void OnGUI()
    {
        if (labelStyle == null)
        {
            labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.fontSize = 18;
            labelStyle.normal.textColor = Color.white;
        }

        if (GUI.Button(new Rect(10, 10, 180, 35), "Recalcular"))
            Recalculate();

        if (result != null)
            GUI.Label(new Rect(10, 55, 900, 700), result.ToReport(), labelStyle);
    }
}
