using UnityEngine;

public enum UiTheme { Azul, Naranja, Verde, Violeta, Personalizado }

// PERSONALIZACIÓN VISUAL DEL JUEGO
// Aquí están TODAS las casillas donde puedes poner tus imágenes: planeta Tierra, cohete,
// estrellas, fondos e interfaz. Todas son OPCIONALES: si una casilla está vacía, el juego
// dibuja un reemplazo para que siempre funcione.
//
// Cómo usarlo: agrega este componente al objeto "Mision" (Add Component > Game Visuals)
// y arrastra tus imágenes a las casillas.
public class GameVisuals : MonoBehaviour
{
    // ============================================================
    [Header("ESTILO")]
    [Tooltip("Marca esto si tus imágenes son pixel art: se ven nítidas, sin borrosidad.")]
    public bool pixelArt = true;

    // ============================================================
    [Header("PLANETA TIERRA (3 fases)")]
    [Tooltip("La nave pasa por la parte iluminada: se ve el planeta de día")]
    public Texture2D earthDay;
    [Tooltip("La nave pasa cerca de la sombra: atardecer / amanecer")]
    public Texture2D earthTwilight;
    [Tooltip("La nave está en eclipse: el planeta de noche")]
    public Texture2D earthNight;
    [Tooltip("Cuántos grados dura la transición de atardecer / amanecer (mayor valor = cambio más suave y progresivo)")]
    [Range(10f, 90f)] public float twilightDegrees = 45f;

    // ============================================================
    [Header("MAPA ORBITAL")]
    [Tooltip("Fondo del espacio en el mapa (ideal 1920x1080)")]
    public Texture2D mapBackground;
    [Tooltip("La imagen de tu satélite (la parte de arriba de la imagen apunta hacia afuera del planeta)")]
    public Texture2D satellite;
    public Texture2D sun;
    [Tooltip("Una estrella (también se usa en el lanzamiento)")]
    public Texture2D star;

    // ============================================================
    [Header("COHETE (General / Fallback)")]
    [Tooltip("Etapa 1: la parte grande de abajo")]
    public Texture2D rocketStage1;
    [Tooltip("Etapa 2: la parte de arriba")]
    public Texture2D rocketStage2;
    [Tooltip("La punta con la carga (opcional)")]
    public Texture2D rocketPayload;
    [Tooltip("La llama del motor (que cuelgue hacia abajo)")]
    public Texture2D rocketFlame;

    // ============================================================
    [Header("MODELOS DE COHETES POR LANZADOR")]
    [Header("Lanzador Ligero (Pequeño)")]
    [Tooltip("Cohete ligero completo")]
    public Texture2D rocketLightComplete;
    [Tooltip("Etapa 1: propulsor inferior")]
    public Texture2D rocketLightStage1;
    [Tooltip("Etapa 2: cápsula / etapa superior")]
    public Texture2D rocketLightStage2;
    [Tooltip("Llama del motor")]
    public Texture2D rocketLightFlame;

    [Header("Lanzador Medio (Mediano)")]
    [Tooltip("Cohete mediano completo")]
    public Texture2D rocketMediumComplete;
    [Tooltip("Etapa 1: propulsor inferior")]
    public Texture2D rocketMediumStage1;
    [Tooltip("Etapa 2: cápsula / etapa superior")]
    public Texture2D rocketMediumStage2;
    [Tooltip("Llama del motor")]
    public Texture2D rocketMediumFlame;

    [Header("Lanzador Pesado (Grande)")]
    [Tooltip("Cohete pesado completo")]
    public Texture2D rocketHeavyComplete;
    [Tooltip("Etapa 1: propulsores inferiores")]
    public Texture2D rocketHeavyStage1;
    [Tooltip("Etapa 2: cápsula / etapa superior")]
    public Texture2D rocketHeavyStage2;
    [Tooltip("Cofia protectora (opcional)")]
    public Texture2D rocketHeavyFairing;
    [Tooltip("Llama del motor")]
    public Texture2D rocketHeavyFlame;

    // ============================================================
    [Header("ESCENA DE LANZAMIENTO")]
    [Tooltip("Cielo de día (se ve al despegar)")]
    public Texture2D launchSky;
    [Tooltip("Espacio (se ve al subir)")]
    public Texture2D launchSpace;
    public Texture2D ground;
    public Texture2D launchPad;
    public Texture2D cloud;

    // ============================================================
    [Header("INTERFAZ DEL SIMULADOR")]
    [Tooltip("Azul, Naranja, Verde y Violeta son estilos listos. 'Personalizado' usa los colores de abajo.")]
    public UiTheme theme = UiTheme.Azul;
    [Tooltip("Tipografía de todos los textos del simulador (opcional)")]
    public Font uiFont;
    [Tooltip("Agranda o achica todas las letras")]
    [Range(0.7f, 1.6f)] public float fontScale = 1f;
    [Tooltip("Imagen de fondo de la pestaña Blueprint")]
    public Texture2D uiBackground;
    [Tooltip("Imagen de fondo de los paneles")]
    public Texture2D panelTexture;
    [Header("Botones (opcional)")]
    public Texture2D buttonNormal;
    public Texture2D buttonHover;
    public Texture2D buttonPressed;
    [Tooltip("Borde en píxeles que NO se estira (para que las esquinas no se deformen)")]
    public int buttonBorder = 6;

    [Header("COLORES (solo con el tema 'Personalizado')")]
    public Color customAccent = new Color(1f, 0.55f, 0.1f);
    public Color customHighlight = new Color(0.2f, 0.7f, 1f);
    public Color customText = Color.white;
    public Color customBackground = new Color(0.03f, 0.04f, 0.08f, 1f);

    // ---------- Colores del tema ----------
    static readonly Color[] PresetAccent =
    {
        new Color(1f, 0.55f, 0.10f),   // Azul: títulos naranjas
        new Color(1f, 0.82f, 0.25f),   // Naranja: títulos amarillos
        new Color(0.55f, 1f, 0.65f),   // Verde
        new Color(0.97f, 0.65f, 1f)    // Violeta
    };
    static readonly Color[] PresetHighlight =
    {
        new Color(0.20f, 0.70f, 1f),
        new Color(1f, 0.50f, 0.10f),
        new Color(0.20f, 0.90f, 0.50f),
        new Color(0.70f, 0.50f, 1f)
    };
    static readonly Color[] PresetBackground =
    {
        new Color(0.03f, 0.04f, 0.08f, 1f),
        new Color(0.08f, 0.05f, 0.03f, 1f),
        new Color(0.02f, 0.07f, 0.05f, 1f),
        new Color(0.06f, 0.03f, 0.10f, 1f)
    };

    bool IsCustom { get { return theme == UiTheme.Personalizado; } }
    int Idx { get { return Mathf.Clamp((int)theme, 0, 3); } }

    public Color Accent { get { return IsCustom ? customAccent : PresetAccent[Idx]; } }
    public Color Highlight { get { return IsCustom ? customHighlight : PresetHighlight[Idx]; } }
    public Color TextColor { get { return IsCustom ? customText : Color.white; } }
    public Color BackgroundColor { get { return IsCustom ? customBackground : PresetBackground[Idx]; } }
    public Color PanelColor
    {
        get
        {
            Color b = BackgroundColor;
            return new Color(b.r, b.g, b.b, 0.92f);
        }
    }

    public void SetTheme(UiTheme t)
    {
        theme = t;
    }

    // ---------- Texturas de botón (las tuyas o unas planas del color del tema) ----------
    // state: 0 normal, 1 al pasar el cursor, 2 presionado
    public Texture2D ButtonTexture(int state)
    {
        Texture2D mine = (state == 2) ? buttonPressed : (state == 1 ? buttonHover : buttonNormal);
        if (mine != null) return mine;
        if (state != 0 && buttonNormal != null) return buttonNormal; // sin hover/pressed propios: usa el normal

        Color bg = BackgroundColor;
        float mix = (state == 0) ? 0.18f : (state == 1 ? 0.38f : 0.62f);
        Color fill = Color.Lerp(bg, Highlight, mix);
        Color border = Highlight * 0.85f;
        border.a = 1f;
        return MakeFlat(fill, border);
    }

    static Texture2D MakeFlat(Color fill, Color border)
    {
        int s = 12;
        var tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < s; y++)
            for (int x = 0; x < s; x++)
                tex.SetPixel(x, y, (x < 2 || y < 2 || x >= s - 2 || y >= s - 2) ? border : fill);
        tex.Apply();
        return tex;
    }

    // ---------- Sprites a partir de texturas ----------

    // El sprite mide 1 unidad de alto (el ancho depende de la imagen). Escálalo con localScale.
    public static Sprite MakeSprite(Texture2D t)
    {
        return Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0.5f, 0.5f), t.height, 0, SpriteMeshType.FullRect);
    }

    // Sprite que se repite (para el suelo): cada repetición mide "tileWidth" unidades de ancho.
    public static Sprite MakeTiledSprite(Texture2D t, float tileWidth)
    {
        return Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0.5f, 0.5f), t.width / tileWidth, 0, SpriteMeshType.FullRect);
    }

    void Awake()
    {
#if UNITY_EDITOR
        AutoAssignDefaults();
#endif
        ApplyFilter();
    }

#if UNITY_EDITOR
    void Reset()
    {
        AutoAssignDefaults();
    }

    void OnValidate()
    {
        AutoAssignDefaults();
    }

    public void AutoAssignDefaults()
    {
        if (earthDay == null)
            earthDay = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/earth_day.png");
        if (earthTwilight == null)
            earthTwilight = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/earth_sunset.png");
        if (earthNight == null)
            earthNight = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/earth_night.png");
        if (mapBackground == null)
            mapBackground = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/ui_background.png");
        if (panelTexture == null)
            panelTexture = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/ui_panel.png");
        if (buttonNormal == null)
            buttonNormal = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/ui_button_normal.png");
        if (buttonHover == null)
            buttonHover = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/ui_button_hover.png");
        if (buttonPressed == null)
            buttonPressed = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/ui_button_pressed.png");

        // Modelos de cohetes
        if (rocketLightComplete == null)
            rocketLightComplete = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_ligero_completo.png");
        if (rocketLightStage1 == null)
            rocketLightStage1 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_ligero_etapa1.png");
        if (rocketLightStage2 == null)
            rocketLightStage2 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_ligero_etapa2.png");
        if (rocketLightFlame == null)
            rocketLightFlame = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_ligero_llama.png");

        if (rocketMediumComplete == null)
            rocketMediumComplete = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_medio_completo.png");
        if (rocketMediumStage1 == null)
            rocketMediumStage1 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_medio_etapa1.png");
        if (rocketMediumStage2 == null)
            rocketMediumStage2 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_medio_etapa2.png");
        if (rocketMediumFlame == null)
            rocketMediumFlame = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_medio_llama.png");

        if (rocketHeavyComplete == null)
            rocketHeavyComplete = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_pesado_completo.png");
        if (rocketHeavyStage1 == null)
            rocketHeavyStage1 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_pesado_etapa1_alta.png");
        if (rocketHeavyStage2 == null)
            rocketHeavyStage2 = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_pesado_etapa2.png");
        if (rocketHeavyFairing == null)
            rocketHeavyFairing = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_pesado_cofia.png");
        if (rocketHeavyFlame == null)
            rocketHeavyFlame = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Arte/Cohetes/cohete_pesado_llama.png");

        if (rocketStage1 == null) rocketStage1 = rocketLightStage1;
        if (rocketStage2 == null) rocketStage2 = rocketLightStage2;
        if (rocketFlame == null) rocketFlame = rocketLightFlame;
    }
#endif

    // Pixel art: filtro "Point" para que no se vea borroso.
    void ApplyFilter()
    {
        if (!pixelArt) return;
        Texture2D[] all =
        {
            earthDay, earthTwilight, earthNight, mapBackground, satellite, sun, star,
            rocketStage1, rocketStage2, rocketPayload, rocketFlame,
            rocketLightComplete, rocketLightStage1, rocketLightStage2, rocketLightFlame,
            rocketMediumComplete, rocketMediumStage1, rocketMediumStage2, rocketMediumFlame,
            rocketHeavyComplete, rocketHeavyStage1, rocketHeavyStage2, rocketHeavyFairing, rocketHeavyFlame,
            launchSky, launchSpace, ground, launchPad, cloud, uiBackground, panelTexture,
            buttonNormal, buttonHover, buttonPressed
        };
        foreach (var t in all)
            if (t != null) t.filterMode = FilterMode.Point;
    }
}
