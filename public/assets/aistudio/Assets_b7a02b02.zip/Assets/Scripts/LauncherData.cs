using UnityEngine;

[CreateAssetMenu(fileName = "NewLauncher", menuName = "Orbital Trade-Off/Launcher")]
public class LauncherData : ScriptableObject
{
    public string launcherName = "Nuevo lanzador";
    [Tooltip("Masa máxima (kg) que puede dejar en órbita baja")]
    public float capacityKg;
    [Tooltip("Costo en millones de dólares")]
    public float costMillions;
}
